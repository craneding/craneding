package com.mysql.jdbc;

import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
import com.mysql.jdbc.exceptions.MySQLTimeoutException;
import com.mysql.jdbc.profiler.ProfilerEvent;
import com.mysql.jdbc.profiler.ProfilerEventHandler;
import com.mysql.jdbc.profiler.ProfilerEventHandlerFactory;
import java.io.InputStream;
import java.math.BigInteger;
import java.sql.BatchUpdateException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class StatementImpl
  implements Statement
{
  protected static final String PING_MARKER = "/* ping */";
  protected java.lang.Object cancelTimeoutMutex = new java.lang.Object();
  protected static int statementCounter = 1;
  public static final byte USES_VARIABLES_FALSE = 0;
  public static final byte USES_VARIABLES_TRUE = 1;
  public static final byte USES_VARIABLES_UNKNOWN = -1;
  protected boolean wasCancelled = false;
  protected boolean wasCancelledByTimeout = false;
  protected List batchedArgs;
  protected SingleByteCharsetConverter charConverter = null;
  protected String charEncoding = null;
  protected ConnectionImpl connection = null;
  protected long connectionId = 0L;
  protected String currentCatalog = null;
  protected boolean doEscapeProcessing = true;
  protected ProfilerEventHandler eventSink = null;
  private int fetchSize = 0;
  protected boolean isClosed = false;
  protected long lastInsertId = -1L;
  protected int maxFieldSize = MysqlIO.getMaxBuf();
  protected int maxRows = -1;
  protected boolean maxRowsChanged = false;
  protected Set openResults = new HashSet();
  protected boolean pedantic = false;
  protected Throwable pointOfOrigin;
  protected boolean profileSQL = false;
  protected ResultSetInternalMethods results = null;
  protected int resultSetConcurrency = 0;
  protected int resultSetType = 0;
  protected int statementId;
  protected int timeoutInMillis = 0;
  protected long updateCount = -1L;
  protected boolean useUsageAdvisor = false;
  protected SQLWarning warningChain = null;
  protected boolean holdResultsOpenOverClose = false;
  protected ArrayList batchedGeneratedKeys = null;
  protected boolean retrieveGeneratedKeys = false;
  protected boolean continueBatchOnError = false;
  protected PingTarget pingTarget = null;
  protected boolean useLegacyDatetimeCode;
  private ExceptionInterceptor exceptionInterceptor;
  protected boolean lastQueryIsOnDupKeyUpdate = false;
  private int originalResultSetType = 0;
  private int originalFetchSize = 0;
  private boolean isPoolable = true;
  private InputStream localInfileInputStream;

  public StatementImpl(ConnectionImpl c, String catalog)
    throws SQLException
  {
    if ((c == null) || (c.isClosed())) {
      throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);
    }

    this.connection = c;
    this.connectionId = this.connection.getId();
    this.exceptionInterceptor = c.getExceptionInterceptor();

    this.currentCatalog = catalog;
    this.pedantic = this.connection.getPedantic();
    this.continueBatchOnError = this.connection.getContinueBatchOnError();
    this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();

    if (!(this.connection.getDontTrackOpenResources())) {
      this.connection.registerStatement(this);
    }

    if (this.connection != null) {
      this.maxFieldSize = this.connection.getMaxAllowedPacket();

      int defaultFetchSize = this.connection.getDefaultFetchSize();

      if (defaultFetchSize != 0)
        setFetchSize(defaultFetchSize);

    }

    if (this.connection.getUseUnicode()) {
      this.charEncoding = this.connection.getEncoding();

      this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
    }

    boolean profiling = (this.connection.getProfileSql()) || (this.connection.getUseUsageAdvisor()) || (this.connection.getLogSlowQueries());

    if ((this.connection.getAutoGenerateTestcaseScript()) || (profiling)) {
      this.statementId = (statementCounter++);
    }

    if (profiling) {
      this.pointOfOrigin = new Throwable();
      this.profileSQL = this.connection.getProfileSql();
      this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
      this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
    }

    int maxRowsConn = this.connection.getMaxRows();

    if (maxRowsConn != -1) {
      setMaxRows(maxRowsConn);
    }

    this.holdResultsOpenOverClose = this.connection.getHoldResultsOpenOverStatementClose();
  }

  public synchronized void addBatch(String sql)
    throws SQLException
  {
    if (this.batchedArgs == null) {
      this.batchedArgs = new ArrayList();
    }

    if (sql != null)
      this.batchedArgs.add(sql);
  }

  public void cancel()
    throws SQLException
  {
    if ((!(this.isClosed)) && (this.connection != null) && (this.connection.versionMeetsMinimum(5, 0, 0)))
    {
      Connection cancelConn = null;
      Statement cancelStmt = null;
      try
      {
        cancelConn = this.connection.duplicate();
        cancelStmt = cancelConn.createStatement();
        cancelStmt.execute("KILL QUERY " + this.connection.getIO().getThreadId());

        this.wasCancelled = true;
      } finally {
        if (cancelStmt != null) {
          cancelStmt.close();
        }

        if (cancelConn != null)
          cancelConn.close();
      }
    }
  }

  protected void checkClosed()
    throws SQLException
  {
    if (this.isClosed)
      throw SQLError.createSQLException(Messages.getString("Statement.49"), "08003", getExceptionInterceptor());
  }

  protected void checkForDml(String sql, char firstStatementChar)
    throws SQLException
  {
    if ((firstStatementChar == 'I') || (firstStatementChar == 'U') || (firstStatementChar == 'D') || (firstStatementChar == 'A') || (firstStatementChar == 'C'))
    {
      String noCommentSql = StringUtils.stripComments(sql, "'\"", "'\"", true, false, true, true);

      if ((StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DROP")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "CREATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "ALTER")))
      {
        throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());
      }
    }
  }

  protected void checkNullOrEmptyQuery(String sql)
    throws SQLException
  {
    if (sql == null) {
      throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
    }

    if (sql.length() == 0)
      throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
  }

  public synchronized void clearBatch()
    throws SQLException
  {
    if (this.batchedArgs != null)
      this.batchedArgs.clear();
  }

  public void clearWarnings()
    throws SQLException
  {
    this.warningChain = null;
  }

  public synchronized void close()
    throws SQLException
  {
    realClose(true, true);
  }

  protected synchronized void closeAllOpenResults()
  {
    if (this.openResults != null) {
      for (Iterator iter = this.openResults.iterator(); iter.hasNext(); ) {
        ResultSetInternalMethods element = (ResultSetInternalMethods)iter.next();
        try
        {
          element.realClose(false);
        } catch (SQLException sqlEx) {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
      }

      this.openResults.clear();
    }
  }

  public synchronized void removeOpenResultSet(ResultSet rs) {
    if (this.openResults != null)
      this.openResults.remove(rs);
  }

  public synchronized int getOpenResultSetCount()
  {
    if (this.openResults != null) {
      return this.openResults.size();
    }

    return 0;
  }

  private ResultSetInternalMethods createResultSetUsingServerFetch(String sql)
    throws SQLException
  {
    java.sql.PreparedStatement pStmt = this.connection.prepareStatement(sql, this.resultSetType, this.resultSetConcurrency);

    pStmt.setFetchSize(this.fetchSize);

    if (this.maxRows > -1) {
      pStmt.setMaxRows(this.maxRows);
    }

    pStmt.execute();

    ResultSetInternalMethods rs = ((StatementImpl)pStmt).getResultSetInternal();

    rs.setStatementUsedForFetchingRows((PreparedStatement)pStmt);

    this.results = rs;

    return rs;
  }

  protected boolean createStreamingResultSet()
  {
    return ((this.resultSetType == 1003) && (this.resultSetConcurrency == 1007) && (this.fetchSize == -2147483648));
  }

  public void enableStreamingResults()
    throws SQLException
  {
    this.originalResultSetType = this.resultSetType;
    this.originalFetchSize = this.fetchSize;

    setFetchSize(-2147483648);
    setResultSetType(1003);
  }

  public void disableStreamingResults() throws SQLException {
    if ((this.fetchSize == -2147483648) && (this.resultSetType == 1003))
    {
      setFetchSize(this.originalFetchSize);
      setResultSetType(this.originalResultSetType);
    }
  }

  public boolean execute(String sql)
    throws SQLException
  {
    return execute(sql, false);
  }

  private boolean execute(String sql, boolean returnGeneratedKeys) throws SQLException {
    checkClosed();

    ConnectionImpl locallyScopedConn = this.connection;

    synchronized (locallyScopedConn.getMutex()) {
      this.retrieveGeneratedKeys = returnGeneratedKeys;
      this.lastQueryIsOnDupKeyUpdate = false;
      if (returnGeneratedKeys)
        this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyInString(sql);

      resetCancelledState();

      checkNullOrEmptyQuery(sql);

      checkClosed();

      char firstNonWsChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));

      boolean isSelect = true;

      if (firstNonWsChar != 'S') {
        isSelect = false;

        if (locallyScopedConn.isReadOnly()) {
          throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009", getExceptionInterceptor());
        }

      }

      boolean doStreaming = createStreamingResultSet();

      if ((doStreaming) && (this.connection.getNetTimeoutForStreamingResults() > 0))
      {
        executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
      }

      if (this.doEscapeProcessing) {
        java.lang.Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), locallyScopedConn);

        if (escapedSqlResult instanceof String)
          sql = (String)escapedSqlResult;
        else
          sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;

      }

      if ((this.results != null) && 
        (!(locallyScopedConn.getHoldResultsOpenOverStatementClose()))) {
        this.results.realClose(false);
      }

      if ((sql.charAt(0) != '/') || 
        (!(sql.startsWith("/* ping */")))) break label267;
      doPingInstead();

      return true;

      label267: CachedResultSetMetaData cachedMetaData = null;

      ResultSetInternalMethods rs = null;

      this.batchedGeneratedKeys = null;

      if (!(useServerFetch())) break label295;
      rs = createResultSetUsingServerFetch(sql); break label685:

      label295: CancelTask timeoutTask = null;

      String oldCatalog = null;
      try
      {
        if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
        {
          timeoutTask = new CancelTask(this, this);
          ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
        }

        if (!(locallyScopedConn.getCatalog().equals(this.currentCatalog)))
        {
          oldCatalog = locallyScopedConn.getCatalog();
          locallyScopedConn.setCatalog(this.currentCatalog);
        }

        Field[] cachedFields = null;

        if (locallyScopedConn.getCacheResultSetMetadata()) {
          cachedMetaData = locallyScopedConn.getCachedMetaData(sql);

          if (cachedMetaData != null) {
            cachedFields = cachedMetaData.fields;
          }

        }

        if (locallyScopedConn.useMaxRows()) {
          ??? = -1;

          if (isSelect) {
            if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
              ??? = this.maxRows;
            }
            else if (this.maxRows <= 0) {
              executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
            }
            else {
              executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
            }

          }
          else
          {
            executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
          }

          rs = locallyScopedConn.execSQL(this, sql, ???, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
        }
        else
        {
          rs = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
        }

        if (timeoutTask != null) {
          if (timeoutTask.caughtWhileCancelling != null) {
            throw timeoutTask.caughtWhileCancelling;
          }

          timeoutTask.cancel();
          timeoutTask = null;
        }

        synchronized (this.cancelTimeoutMutex) {
          if (this.wasCancelled) {
            SQLException cause = null;

            if (this.wasCancelledByTimeout)
              cause = new MySQLTimeoutException();
            else {
              cause = new MySQLStatementCancelledException();
            }

            resetCancelledState();

            throw cause;
          }
        }
      } finally {
        if (timeoutTask != null) {
          timeoutTask.cancel();
        }

        if (oldCatalog != null) {
          locallyScopedConn.setCatalog(oldCatalog);
        }

      }

      label685: if (rs == null) break label765;
      this.lastInsertId = rs.getUpdateID();

      this.results = rs;

      rs.setFirstCharOfQuery(firstNonWsChar);

      if (!(rs.reallyResult())) break label765;
      if (cachedMetaData == null) break label745;
      locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results); break label765:

      label745: if (!(this.connection.getCacheResultSetMetadata())) break label765;
      locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);

      label765: return (((rs != null) && (rs.reallyResult())) ? 1 : false);
    }
  }

  protected synchronized void resetCancelledState() {
    if (this.cancelTimeoutMutex == null) {
      return;
    }

    synchronized (this.cancelTimeoutMutex) {
      this.wasCancelled = false;
      this.wasCancelledByTimeout = false; }  } 
  // ERROR //
  public boolean execute(String sql, int returnGeneratedKeys) throws SQLException { // Byte code:
    //   0: iload_2
    //   1: iconst_1
    //   2: if_icmpne +73 -> 75
    //   5: aload_0
    //   6: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   9: aload_0
    //   10: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   13: astore_3
    //   14: aload_3
    //   15: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   18: dup
    //   19: astore 4
    //   21: monitorenter
    //   22: aload_0
    //   23: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   26: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   29: istore 5
    //   31: aload_3
    //   32: iconst_1
    //   33: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   36: aload_0
    //   37: aload_1
    //   38: iconst_1
    //   39: invokespecial 132	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;Z)Z
    //   42: istore 6
    //   44: aload_3
    //   45: iload 5
    //   47: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   50: aload 4
    //   52: monitorexit
    //   53: iload 6
    //   55: ireturn
    //   56: astore 7
    //   58: aload_3
    //   59: iload 5
    //   61: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   64: aload 7
    //   66: athrow
    //   67: astore 8
    //   69: aload 4
    //   71: monitorexit
    //   72: aload 8
    //   74: athrow
    //   75: aload_0
    //   76: aload_1
    //   77: invokevirtual 188	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;)Z
    //   80: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   36	44	56	finally
    //   56	58	56	finally
    //   22	53	67	finally
    //   56	72	67	finally } 
  // ERROR //
  public boolean execute(String sql, int[] generatedKeyIndices) throws SQLException { // Byte code:
    //   0: aload_2
    //   1: ifnull +80 -> 81
    //   4: aload_2
    //   5: arraylength
    //   6: ifle +75 -> 81
    //   9: aload_0
    //   10: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   13: aload_0
    //   14: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   17: astore_3
    //   18: aload_3
    //   19: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   22: dup
    //   23: astore 4
    //   25: monitorenter
    //   26: aload_0
    //   27: iconst_1
    //   28: putfield 36	com/mysql/jdbc/StatementImpl:retrieveGeneratedKeys	Z
    //   31: aload_3
    //   32: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   35: istore 5
    //   37: aload_3
    //   38: iconst_1
    //   39: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   42: aload_0
    //   43: aload_1
    //   44: iconst_1
    //   45: invokespecial 132	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;Z)Z
    //   48: istore 6
    //   50: aload_3
    //   51: iload 5
    //   53: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   56: aload 4
    //   58: monitorexit
    //   59: iload 6
    //   61: ireturn
    //   62: astore 7
    //   64: aload_3
    //   65: iload 5
    //   67: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   70: aload 7
    //   72: athrow
    //   73: astore 8
    //   75: aload 4
    //   77: monitorexit
    //   78: aload 8
    //   80: athrow
    //   81: aload_0
    //   82: aload_1
    //   83: invokevirtual 188	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;)Z
    //   86: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   42	50	62	finally
    //   62	64	62	finally
    //   26	59	73	finally
    //   62	78	73	finally } 
  // ERROR //
  public boolean execute(String sql, String[] generatedKeyNames) throws SQLException { // Byte code:
    //   0: aload_2
    //   1: ifnull +83 -> 84
    //   4: aload_2
    //   5: arraylength
    //   6: ifle +78 -> 84
    //   9: aload_0
    //   10: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   13: aload_0
    //   14: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   17: astore_3
    //   18: aload_3
    //   19: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   22: dup
    //   23: astore 4
    //   25: monitorenter
    //   26: aload_0
    //   27: iconst_1
    //   28: putfield 36	com/mysql/jdbc/StatementImpl:retrieveGeneratedKeys	Z
    //   31: aload_0
    //   32: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   35: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   38: istore 5
    //   40: aload_3
    //   41: iconst_1
    //   42: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   45: aload_0
    //   46: aload_1
    //   47: iconst_1
    //   48: invokespecial 132	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;Z)Z
    //   51: istore 6
    //   53: aload_3
    //   54: iload 5
    //   56: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   59: aload 4
    //   61: monitorexit
    //   62: iload 6
    //   64: ireturn
    //   65: astore 7
    //   67: aload_3
    //   68: iload 5
    //   70: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   73: aload 7
    //   75: athrow
    //   76: astore 8
    //   78: aload 4
    //   80: monitorexit
    //   81: aload 8
    //   83: athrow
    //   84: aload_0
    //   85: aload_1
    //   86: invokevirtual 188	com/mysql/jdbc/StatementImpl:execute	(Ljava/lang/String;)Z
    //   89: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   45	53	65	finally
    //   65	67	65	finally
    //   26	62	76	finally
    //   65	81	76	finally } 
  // ERROR //
  public synchronized int[] executeBatch() throws SQLException { // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   4: aload_0
    //   5: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   8: astore_1
    //   9: aload_1
    //   10: invokevirtual 140	com/mysql/jdbc/ConnectionImpl:isReadOnly	()Z
    //   13: ifeq +39 -> 52
    //   16: new 83	java/lang/StringBuffer
    //   19: dup
    //   20: invokespecial 84	java/lang/StringBuffer:<init>	()V
    //   23: ldc 189
    //   25: invokestatic 45	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   28: invokevirtual 86	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   31: ldc 190
    //   33: invokestatic 45	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   36: invokevirtual 86	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   39: invokevirtual 90	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   42: ldc 106
    //   44: aload_0
    //   45: invokevirtual 95	com/mysql/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
    //   48: invokestatic 47	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   51: athrow
    //   52: aload_0
    //   53: getfield 27	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
    //   56: ifnull +20 -> 76
    //   59: aload_1
    //   60: invokevirtual 75	com/mysql/jdbc/ConnectionImpl:getHoldResultsOpenOverStatementClose	()Z
    //   63: ifne +13 -> 76
    //   66: aload_0
    //   67: getfield 27	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
    //   70: iconst_0
    //   71: invokeinterface 116 2 0
    //   76: aload_1
    //   77: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   80: dup
    //   81: astore_2
    //   82: monitorenter
    //   83: aload_0
    //   84: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   87: ifnull +15 -> 102
    //   90: aload_0
    //   91: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   94: invokeinterface 191 1 0
    //   99: ifne +9 -> 108
    //   102: iconst_0
    //   103: newarray int
    //   105: aload_2
    //   106: monitorexit
    //   107: areturn
    //   108: aload_0
    //   109: getfield 30	com/mysql/jdbc/StatementImpl:timeoutInMillis	I
    //   112: istore_3
    //   113: aload_0
    //   114: iconst_0
    //   115: putfield 30	com/mysql/jdbc/StatementImpl:timeoutInMillis	I
    //   118: aconst_null
    //   119: astore 4
    //   121: aload_0
    //   122: invokevirtual 136	com/mysql/jdbc/StatementImpl:resetCancelledState	()V
    //   125: aload_0
    //   126: iconst_1
    //   127: putfield 36	com/mysql/jdbc/StatementImpl:retrieveGeneratedKeys	Z
    //   130: aconst_null
    //   131: astore 5
    //   133: aload_0
    //   134: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   137: ifnull +386 -> 523
    //   140: aload_0
    //   141: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   144: invokeinterface 191 1 0
    //   149: istore 6
    //   151: aload_0
    //   152: new 77	java/util/ArrayList
    //   155: dup
    //   156: aload_0
    //   157: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   160: invokeinterface 191 1 0
    //   165: invokespecial 192	java/util/ArrayList:<init>	(I)V
    //   168: putfield 35	com/mysql/jdbc/StatementImpl:batchedGeneratedKeys	Ljava/util/ArrayList;
    //   171: aload_1
    //   172: invokevirtual 193	com/mysql/jdbc/ConnectionImpl:getAllowMultiQueries	()Z
    //   175: istore 7
    //   177: aload_1
    //   178: iconst_4
    //   179: iconst_1
    //   180: iconst_1
    //   181: invokevirtual 80	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
    //   184: ifeq +40 -> 224
    //   187: iload 7
    //   189: ifne +16 -> 205
    //   192: aload_1
    //   193: invokevirtual 194	com/mysql/jdbc/ConnectionImpl:getRewriteBatchedStatements	()Z
    //   196: ifeq +28 -> 224
    //   199: iload 6
    //   201: iconst_4
    //   202: if_icmple +22 -> 224
    //   205: aload_0
    //   206: iload 7
    //   208: iload 6
    //   210: iload_3
    //   211: invokespecial 195	com/mysql/jdbc/StatementImpl:executeBatchUsingMultiQueries	(ZII)[I
    //   214: astore 8
    //   216: jsr +366 -> 582
    //   219: aload_2
    //   220: monitorexit
    //   221: aload 8
    //   223: areturn
    //   224: aload_1
    //   225: invokevirtual 159	com/mysql/jdbc/ConnectionImpl:getEnableQueryTimeouts	()Z
    //   228: ifeq +38 -> 266
    //   231: iload_3
    //   232: ifeq +34 -> 266
    //   235: aload_1
    //   236: iconst_5
    //   237: iconst_0
    //   238: iconst_0
    //   239: invokevirtual 80	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
    //   242: ifeq +24 -> 266
    //   245: new 160	com/mysql/jdbc/StatementImpl$CancelTask
    //   248: dup
    //   249: aload_0
    //   250: aload_0
    //   251: invokespecial 161	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
    //   254: astore 4
    //   256: invokestatic 162	com/mysql/jdbc/ConnectionImpl:getCancelTimer	()Ljava/util/Timer;
    //   259: aload 4
    //   261: iload_3
    //   262: i2l
    //   263: invokevirtual 163	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
    //   266: iload 6
    //   268: newarray int
    //   270: astore 5
    //   272: iconst_0
    //   273: istore 8
    //   275: iload 8
    //   277: iload 6
    //   279: if_icmpge +16 -> 295
    //   282: aload 5
    //   284: iload 8
    //   286: bipush 253
    //   288: iastore
    //   289: iinc 8 1
    //   292: goto -17 -> 275
    //   295: aconst_null
    //   296: astore 8
    //   298: iconst_0
    //   299: istore 9
    //   301: iconst_0
    //   302: istore 9
    //   304: iload 9
    //   306: iload 6
    //   308: if_icmpge +185 -> 493
    //   311: aload_0
    //   312: getfield 76	com/mysql/jdbc/StatementImpl:batchedArgs	Ljava/util/List;
    //   315: iload 9
    //   317: invokeinterface 196 2 0
    //   322: checkcast 150	java/lang/String
    //   325: astore 10
    //   327: aload 5
    //   329: iload 9
    //   331: aload_0
    //   332: aload 10
    //   334: iconst_1
    //   335: iconst_1
    //   336: invokevirtual 197	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;ZZ)I
    //   339: iastore
    //   340: aload_0
    //   341: aload_0
    //   342: aload 10
    //   344: invokevirtual 135	com/mysql/jdbc/StatementImpl:containsOnDuplicateKeyInString	(Ljava/lang/String;)Z
    //   347: ifeq +7 -> 354
    //   350: iconst_1
    //   351: goto +4 -> 355
    //   354: iconst_0
    //   355: invokevirtual 198	com/mysql/jdbc/StatementImpl:getBatchedGeneratedKeys	(I)V
    //   358: goto +129 -> 487
    //   361: astore 10
    //   363: aload 5
    //   365: iload 9
    //   367: bipush 253
    //   369: iastore
    //   370: aload_0
    //   371: getfield 37	com/mysql/jdbc/StatementImpl:continueBatchOnError	Z
    //   374: ifeq +35 -> 409
    //   377: aload 10
    //   379: instanceof 178
    //   382: ifne +27 -> 409
    //   385: aload 10
    //   387: instanceof 180
    //   390: ifne +19 -> 409
    //   393: aload_0
    //   394: aload 10
    //   396: invokevirtual 199	com/mysql/jdbc/StatementImpl:hasDeadlockOrTimeoutRolledBackTx	(Ljava/sql/SQLException;)Z
    //   399: ifne +10 -> 409
    //   402: aload 10
    //   404: astore 8
    //   406: goto +81 -> 487
    //   409: iload 9
    //   411: newarray int
    //   413: astore 11
    //   415: aload_0
    //   416: aload 10
    //   418: invokevirtual 199	com/mysql/jdbc/StatementImpl:hasDeadlockOrTimeoutRolledBackTx	(Ljava/sql/SQLException;)Z
    //   421: ifeq +30 -> 451
    //   424: iconst_0
    //   425: istore 12
    //   427: iload 12
    //   429: aload 11
    //   431: arraylength
    //   432: if_icmpge +16 -> 448
    //   435: aload 11
    //   437: iload 12
    //   439: bipush 253
    //   441: iastore
    //   442: iinc 12 1
    //   445: goto -18 -> 427
    //   448: goto +14 -> 462
    //   451: aload 5
    //   453: iconst_0
    //   454: aload 11
    //   456: iconst_0
    //   457: iload 9
    //   459: invokestatic 200	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   462: new 201	java/sql/BatchUpdateException
    //   465: dup
    //   466: aload 10
    //   468: invokevirtual 202	SQLException:getMessage	()Ljava/lang/String;
    //   471: aload 10
    //   473: invokevirtual 203	SQLException:getSQLState	()Ljava/lang/String;
    //   476: aload 10
    //   478: invokevirtual 204	SQLException:getErrorCode	()I
    //   481: aload 11
    //   483: invokespecial 205	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
    //   486: athrow
    //   487: iinc 9 1
    //   490: goto -186 -> 304
    //   493: aload 8
    //   495: ifnull +28 -> 523
    //   498: new 201	java/sql/BatchUpdateException
    //   501: dup
    //   502: aload 8
    //   504: invokevirtual 202	SQLException:getMessage	()Ljava/lang/String;
    //   507: aload 8
    //   509: invokevirtual 203	SQLException:getSQLState	()Ljava/lang/String;
    //   512: aload 8
    //   514: invokevirtual 204	SQLException:getErrorCode	()I
    //   517: aload 5
    //   519: invokespecial 205	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
    //   522: athrow
    //   523: aload 4
    //   525: ifnull +26 -> 551
    //   528: aload 4
    //   530: getfield 176	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
    //   533: ifnull +9 -> 542
    //   536: aload 4
    //   538: getfield 176	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
    //   541: athrow
    //   542: aload 4
    //   544: invokevirtual 177	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   547: pop
    //   548: aconst_null
    //   549: astore 4
    //   551: aload 5
    //   553: ifnull +8 -> 561
    //   556: aload 5
    //   558: goto +6 -> 564
    //   561: iconst_0
    //   562: newarray int
    //   564: astore 6
    //   566: jsr +16 -> 582
    //   569: aload_2
    //   570: monitorexit
    //   571: aload 6
    //   573: areturn
    //   574: astore 13
    //   576: jsr +6 -> 582
    //   579: aload 13
    //   581: athrow
    //   582: astore 14
    //   584: aload 4
    //   586: ifnull +9 -> 595
    //   589: aload 4
    //   591: invokevirtual 177	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   594: pop
    //   595: aload_0
    //   596: invokevirtual 136	com/mysql/jdbc/StatementImpl:resetCancelledState	()V
    //   599: aload_0
    //   600: iload_3
    //   601: putfield 30	com/mysql/jdbc/StatementImpl:timeoutInMillis	I
    //   604: aload_0
    //   605: invokevirtual 206	com/mysql/jdbc/StatementImpl:clearBatch	()V
    //   608: ret 14
    //   610: astore 15
    //   612: aload_2
    //   613: monitorexit
    //   614: aload 15
    //   616: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   311	358	361	SQLException
    //   121	219	574	finally
    //   224	569	574	finally
    //   574	579	574	finally
    //   83	107	610	finally
    //   108	221	610	finally
    //   224	571	610	finally
    //   574	614	610	finally } 
  protected final boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex) { int vendorCode = ex.getErrorCode();

    switch (vendorCode) {
    case 1206:
    case 1213:
      return true;
    case 1205:
      try {
        return (!(this.connection.versionMeetsMinimum(5, 0, 13)));
      }
      catch (SQLException sqlEx) {
        return false;
      }
    }
    return false;
  }

  private int[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, int individualStatementTimeout)
    throws SQLException
  {
    ConnectionImpl locallyScopedConn = this.connection;

    if (!(multiQueriesEnabled)) {
      locallyScopedConn.getIO().enableMultiQueries();
    }

    Statement batchStmt = null;

    CancelTask timeoutTask = null;
    try
    {
      int[] updateCounts = new int[nbrCommands];

      for (int i = 0; i < nbrCommands; ++i) {
        updateCounts[i] = -3;
      }

      int commandIndex = 0;

      StringBuffer queryBuf = new StringBuffer();

      batchStmt = locallyScopedConn.createStatement();

      if ((locallyScopedConn.getEnableQueryTimeouts()) && (individualStatementTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
      {
        timeoutTask = new CancelTask(this, (StatementImpl)batchStmt);
        ConnectionImpl.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
      }

      int counter = 0;

      int numberOfBytesPerChar = 1;

      String connectionEncoding = locallyScopedConn.getEncoding();

      if (StringUtils.startsWithIgnoreCase(connectionEncoding, "utf"))
        numberOfBytesPerChar = 3;
      else if (CharsetMapping.isMultibyteCharset(connectionEncoding)) {
        numberOfBytesPerChar = 2;
      }

      int escapeAdjust = 1;

      if (this.doEscapeProcessing) {
        escapeAdjust = 2;
      }

      SQLException sqlEx = null;

      int argumentSetsInBatchSoFar = 0;

      for (commandIndex = 0; commandIndex < nbrCommands; ++commandIndex) {
        String nextQuery = (String)this.batchedArgs.get(commandIndex);

        if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > this.connection.getMaxAllowedPacket())
        {
          try
          {
            batchStmt.execute(queryBuf.toString(), 1);
          } catch (SQLException ex) {
            sqlEx = handleExceptionForBatch(commandIndex, argumentSetsInBatchSoFar, updateCounts, ex);
          }

          counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);

          queryBuf = new StringBuffer();
          argumentSetsInBatchSoFar = 0;
        }

        queryBuf.append(nextQuery);
        queryBuf.append(";");
        ++argumentSetsInBatchSoFar;
      }

      if (queryBuf.length() > 0) {
        try {
          batchStmt.execute(queryBuf.toString(), 1);
        } catch (SQLException ex) {
          sqlEx = handleExceptionForBatch(commandIndex - 1, argumentSetsInBatchSoFar, updateCounts, ex);
        }

        counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
      }

      if (timeoutTask != null) {
        if (timeoutTask.caughtWhileCancelling != null) {
          throw timeoutTask.caughtWhileCancelling;
        }

        timeoutTask.cancel();
        timeoutTask = null;
      }

      if (sqlEx != null) {
        throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
      }

      return ((updateCounts != null) ? updateCounts : new int[0]);
    } finally {
      if (timeoutTask != null) {
        timeoutTask.cancel();
      }

      resetCancelledState();
      try
      {
        if (batchStmt != null)
          batchStmt.close();
      }
      finally {
        if (!(multiQueriesEnabled))
          locallyScopedConn.getIO().disableMultiQueries();
      }
    }
  }

  protected int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, int[] updateCounts)
    throws SQLException
  {
    long generatedKey;
    updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();

    boolean doGenKeys = this.batchedGeneratedKeys != null;

    byte[][] row = (byte[][])null;

    if (doGenKeys) {
      generatedKey = batchedStatement.getLastInsertID();

      row = new byte[1][];
      row[0] = Long.toString(generatedKey).getBytes();
      this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
    }
    while (true) {
      do {
        if ((!(batchedStatement.getMoreResults())) && (batchedStatement.getUpdateCount() == -1)) break label158;
        updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();
      }
      while (!(doGenKeys));
      generatedKey = batchedStatement.getLastInsertID();

      row = new byte[1][];
      row[0] = Long.toString(generatedKey).getBytes();
      this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
    }

    label158: return updateCountCounter;
  }

  protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, int[] updateCounts, SQLException ex)
    throws BatchUpdateException
  {
    SQLException sqlEx;
    for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; --j) {
      updateCounts[j] = -3;
    }

    if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!(hasDeadlockOrTimeoutRolledBackTx(ex))))
    {
      sqlEx = ex;
    } else {
      int[] newUpdateCounts = new int[endOfBatchIndex];
      System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex);

      throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
    }

    return sqlEx;
  }

  public ResultSet executeQuery(String sql)
    throws SQLException
  {
    checkClosed();

    ConnectionImpl locallyScopedConn = this.connection;

    synchronized (locallyScopedConn.getMutex()) {
      this.retrieveGeneratedKeys = false;

      resetCancelledState();

      checkNullOrEmptyQuery(sql);

      boolean doStreaming = createStreamingResultSet();

      if ((doStreaming) && (this.connection.getNetTimeoutForStreamingResults() > 0))
      {
        executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
      }

      if (this.doEscapeProcessing) {
        java.lang.Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), this.connection);

        if (escapedSqlResult instanceof String)
          sql = (String)escapedSqlResult;
        else
          sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;

      }

      char firstStatementChar = StringUtils.firstNonWsCharUc(sql, findStartOfStatement(sql));

      if ((sql.charAt(0) != '/') || 
        (!(sql.startsWith("/* ping */")))) break label169;
      doPingInstead();

      return this.results;

      label169: checkForDml(sql, firstStatementChar);

      if ((this.results == null) || 
        (locallyScopedConn.getHoldResultsOpenOverStatementClose())) break label200;
      this.results.realClose(false);

      label200: CachedResultSetMetaData cachedMetaData = null;

      if (!(useServerFetch())) break label226;
      this.results = createResultSetUsingServerFetch(sql);

      return this.results;

      label226: CancelTask timeoutTask = null;

      String oldCatalog = null;
      try
      {
        if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
        {
          timeoutTask = new CancelTask(this, this);
          ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
        }

        if (!(locallyScopedConn.getCatalog().equals(this.currentCatalog))) {
          oldCatalog = locallyScopedConn.getCatalog();
          locallyScopedConn.setCatalog(this.currentCatalog);
        }

        Field[] cachedFields = null;

        if (locallyScopedConn.getCacheResultSetMetadata()) {
          cachedMetaData = locallyScopedConn.getCachedMetaData(sql);

          if (cachedMetaData != null)
            cachedFields = cachedMetaData.fields;

        }

        if (locallyScopedConn.useMaxRows())
        {
          if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
            this.results = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
          }
          else
          {
            if (this.maxRows <= 0) {
              executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
            }
            else {
              executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
            }

            this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);

            if (oldCatalog != null)
              locallyScopedConn.setCatalog(oldCatalog);
          }
        }
        else {
          this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
        }

        if (timeoutTask != null) {
          if (timeoutTask.caughtWhileCancelling != null) {
            throw timeoutTask.caughtWhileCancelling;
          }

          timeoutTask.cancel();
          timeoutTask = null;
        }

        synchronized (this.cancelTimeoutMutex) {
          if (this.wasCancelled) {
            SQLException cause = null;

            if (this.wasCancelledByTimeout)
              cause = new MySQLTimeoutException();
            else {
              cause = new MySQLStatementCancelledException();
            }

            resetCancelledState();

            throw cause;
          }
        }
      } finally {
        if (timeoutTask != null) {
          timeoutTask.cancel();
        }

        if (oldCatalog != null)
          locallyScopedConn.setCatalog(oldCatalog);

      }

      this.lastInsertId = this.results.getUpdateID();

      if (cachedMetaData == null) break label669;
      locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results); break label689:

      label669: if (!(this.connection.getCacheResultSetMetadata())) break label689;
      locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);

      label689: return this.results;
    }
  }

  protected void doPingInstead() throws SQLException {
    if (this.pingTarget != null)
      this.pingTarget.doPing();
    else {
      this.connection.ping();
    }

    ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet();
    this.results = fakeSelectOneResultSet;
  }

  protected ResultSetInternalMethods generatePingResultSet() throws SQLException {
    Field[] fields = { new Field(null, "1", -5, 1) };
    ArrayList rows = new ArrayList();
    byte[] colVal = { 49 };

    rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor()));

    return ((ResultSetInternalMethods)DatabaseMetaData.buildResultSet(fields, rows, this.connection));
  }

  protected void executeSimpleNonQuery(ConnectionImpl c, String nonQuery)
    throws SQLException
  {
    c.execSQL(this, nonQuery, -1, null, 1003, 1007, false, this.currentCatalog, null, false).close();
  }

  public int executeUpdate(String sql)
    throws SQLException
  {
    return executeUpdate(sql, false, false);
  }

  protected int executeUpdate(String sql, boolean isBatch, boolean returnGeneratedKeys) throws SQLException
  {
    int i;
    checkClosed();

    ConnectionImpl locallyScopedConn = this.connection;

    char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));

    ResultSetInternalMethods rs = null;

    synchronized (locallyScopedConn.getMutex()) {
      this.retrieveGeneratedKeys = returnGeneratedKeys;

      resetCancelledState();

      checkNullOrEmptyQuery(sql);

      if (this.doEscapeProcessing) {
        java.lang.Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.connection.serverSupportsConvertFn(), this.connection);

        if (escapedSqlResult instanceof String)
          sql = (String)escapedSqlResult;
        else
          sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;

      }

      if (locallyScopedConn.isReadOnly()) {
        throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", getExceptionInterceptor());
      }

      if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
        throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());
      }

      if ((this.results != null) && 
        (!(locallyScopedConn.getHoldResultsOpenOverStatementClose()))) {
        this.results.realClose(false);
      }

      CancelTask timeoutTask = null;

      String oldCatalog = null;
      try
      {
        if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
        {
          timeoutTask = new CancelTask(this, this);
          ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
        }

        if (!(locallyScopedConn.getCatalog().equals(this.currentCatalog))) {
          oldCatalog = locallyScopedConn.getCatalog();
          locallyScopedConn.setCatalog(this.currentCatalog);
        }

        if (locallyScopedConn.useMaxRows()) {
          executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
        }

        rs = locallyScopedConn.execSQL(this, sql, -1, null, 1003, 1007, false, this.currentCatalog, null, isBatch);

        if (timeoutTask != null) {
          if (timeoutTask.caughtWhileCancelling != null) {
            throw timeoutTask.caughtWhileCancelling;
          }

          timeoutTask.cancel();
          timeoutTask = null;
        }

        synchronized (this.cancelTimeoutMutex) {
          if (this.wasCancelled) {
            SQLException cause = null;

            if (this.wasCancelledByTimeout)
              cause = new MySQLTimeoutException();
            else {
              cause = new MySQLStatementCancelledException();
            }

            resetCancelledState();

            throw cause;
          }
        }
      } finally {
        if (timeoutTask != null) {
          timeoutTask.cancel();
        }

        if (oldCatalog != null)
          locallyScopedConn.setCatalog(oldCatalog);
      }

    }

    this.results = rs;

    rs.setFirstCharOfQuery(firstStatementChar);

    this.updateCount = rs.getUpdateCount();

    int i = 0;

    if (this.updateCount > 2147483647L)
      i = 2147483647;
    else {
      i = (int)this.updateCount;
    }

    this.lastInsertId = rs.getUpdateID();

    return i; } 
  // ERROR //
  public int executeUpdate(String sql, int returnGeneratedKeys) throws SQLException { // Byte code:
    //   0: iload_2
    //   1: iconst_1
    //   2: if_icmpne +71 -> 73
    //   5: aload_0
    //   6: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   9: aload_0
    //   10: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   13: astore_3
    //   14: aload_3
    //   15: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   18: dup
    //   19: astore 4
    //   21: monitorenter
    //   22: aload_3
    //   23: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   26: istore 5
    //   28: aload_3
    //   29: iconst_1
    //   30: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   33: aload_0
    //   34: aload_1
    //   35: iconst_0
    //   36: iconst_1
    //   37: invokevirtual 197	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;ZZ)I
    //   40: istore 6
    //   42: aload_3
    //   43: iload 5
    //   45: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   48: aload 4
    //   50: monitorexit
    //   51: iload 6
    //   53: ireturn
    //   54: astore 7
    //   56: aload_3
    //   57: iload 5
    //   59: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   62: aload 7
    //   64: athrow
    //   65: astore 8
    //   67: aload 4
    //   69: monitorexit
    //   70: aload 8
    //   72: athrow
    //   73: aload_0
    //   74: aload_1
    //   75: invokevirtual 248	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;)I
    //   78: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   33	42	54	finally
    //   54	56	54	finally
    //   22	51	65	finally
    //   54	70	65	finally } 
  // ERROR //
  public int executeUpdate(String sql, int[] generatedKeyIndices) throws SQLException { // Byte code:
    //   0: aload_2
    //   1: ifnull +76 -> 77
    //   4: aload_2
    //   5: arraylength
    //   6: ifle +71 -> 77
    //   9: aload_0
    //   10: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   13: aload_0
    //   14: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   17: astore_3
    //   18: aload_3
    //   19: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   22: dup
    //   23: astore 4
    //   25: monitorenter
    //   26: aload_3
    //   27: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   30: istore 5
    //   32: aload_3
    //   33: iconst_1
    //   34: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   37: aload_0
    //   38: aload_1
    //   39: iconst_0
    //   40: iconst_1
    //   41: invokevirtual 197	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;ZZ)I
    //   44: istore 6
    //   46: aload_3
    //   47: iload 5
    //   49: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   52: aload 4
    //   54: monitorexit
    //   55: iload 6
    //   57: ireturn
    //   58: astore 7
    //   60: aload_3
    //   61: iload 5
    //   63: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   66: aload 7
    //   68: athrow
    //   69: astore 8
    //   71: aload 4
    //   73: monitorexit
    //   74: aload 8
    //   76: athrow
    //   77: aload_0
    //   78: aload_1
    //   79: invokevirtual 248	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;)I
    //   82: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   37	46	58	finally
    //   58	60	58	finally
    //   26	55	69	finally
    //   58	74	69	finally } 
  // ERROR //
  public int executeUpdate(String sql, String[] generatedKeyNames) throws SQLException { // Byte code:
    //   0: aload_2
    //   1: ifnull +79 -> 80
    //   4: aload_2
    //   5: arraylength
    //   6: ifle +74 -> 80
    //   9: aload_0
    //   10: invokevirtual 133	com/mysql/jdbc/StatementImpl:checkClosed	()V
    //   13: aload_0
    //   14: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   17: astore_3
    //   18: aload_3
    //   19: invokevirtual 134	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   22: dup
    //   23: astore 4
    //   25: monitorenter
    //   26: aload_0
    //   27: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   30: invokevirtual 186	com/mysql/jdbc/ConnectionImpl:isReadInfoMsgEnabled	()Z
    //   33: istore 5
    //   35: aload_3
    //   36: iconst_1
    //   37: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   40: aload_0
    //   41: aload_1
    //   42: iconst_0
    //   43: iconst_1
    //   44: invokevirtual 197	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;ZZ)I
    //   47: istore 6
    //   49: aload_3
    //   50: iload 5
    //   52: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   55: aload 4
    //   57: monitorexit
    //   58: iload 6
    //   60: ireturn
    //   61: astore 7
    //   63: aload_3
    //   64: iload 5
    //   66: invokevirtual 187	com/mysql/jdbc/ConnectionImpl:setReadInfoMsgEnabled	(Z)V
    //   69: aload 7
    //   71: athrow
    //   72: astore 8
    //   74: aload 4
    //   76: monitorexit
    //   77: aload 8
    //   79: athrow
    //   80: aload_0
    //   81: aload_1
    //   82: invokevirtual 248	com/mysql/jdbc/StatementImpl:executeUpdate	(Ljava/lang/String;)I
    //   85: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   40	49	61	finally
    //   61	63	61	finally
    //   26	58	72	finally
    //   61	77	72	finally } 
  protected Calendar getCalendarInstanceForSessionOrNew() { if (this.connection != null) {
      return this.connection.getCalendarInstanceForSessionOrNew();
    }

    return new GregorianCalendar();
  }

  public java.sql.Connection getConnection()
    throws SQLException
  {
    return this.connection;
  }

  public int getFetchDirection()
    throws SQLException
  {
    return 1000;
  }

  public int getFetchSize()
    throws SQLException
  {
    return this.fetchSize;
  }

  public synchronized ResultSet getGeneratedKeys()
    throws SQLException
  {
    if (!(this.retrieveGeneratedKeys)) {
      throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", getExceptionInterceptor());
    }

    if (this.batchedGeneratedKeys == null) {
      if (this.lastQueryIsOnDupKeyUpdate)
        return getGeneratedKeysInternal(1);

      return getGeneratedKeysInternal();
    }

    Field[] fields = new Field[1];
    fields[0] = new Field("", "GENERATED_KEY", -5, 17);
    fields[0].setConnection(this.connection);

    return ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(this.batchedGeneratedKeys), this.connection, this, false);
  }

  protected ResultSet getGeneratedKeysInternal()
    throws SQLException
  {
    int numKeys = getUpdateCount();
    return getGeneratedKeysInternal(numKeys);
  }

  protected synchronized ResultSet getGeneratedKeysInternal(int numKeys) throws SQLException
  {
    int i;
    Field[] fields = new Field[1];
    fields[0] = new Field("", "GENERATED_KEY", -5, 17);
    fields[0].setConnection(this.connection);
    fields[0].setUseOldNameMetadata(true);

    ArrayList rowSet = new ArrayList();

    long beginAt = getLastInsertID();

    if (beginAt < 0L) {
      fields[0].setUnsigned();
    }

    if (this.results != null) {
      String serverInfo = this.results.getServerInfo();

      if ((numKeys > 0) && (this.results.getFirstCharOfQuery() == 'R') && (serverInfo != null) && (serverInfo.length() > 0))
      {
        numKeys = getRecordCountFromInfo(serverInfo);
      }

      if ((beginAt != 0L) && (numKeys > 0))
        for (i = 0; i < numKeys; ++i) {
          byte[][] row = new byte[1][];
          if (beginAt > 0L) {
            row[0] = Long.toString(beginAt).getBytes();
          } else {
            byte[] asBytes = new byte[8];
            asBytes[7] = (byte)(int)(beginAt & 0xFF);
            asBytes[6] = (byte)(int)(beginAt >>> 8);
            asBytes[5] = (byte)(int)(beginAt >>> 16);
            asBytes[4] = (byte)(int)(beginAt >>> 24);
            asBytes[3] = (byte)(int)(beginAt >>> 32);
            asBytes[2] = (byte)(int)(beginAt >>> 40);
            asBytes[1] = (byte)(int)(beginAt >>> 48);
            asBytes[0] = (byte)(int)(beginAt >>> 56);

            BigInteger val = new BigInteger(1, asBytes);

            row[0] = val.toString().getBytes();
          }
          rowSet.add(new ByteArrayRow(row, getExceptionInterceptor()));
          beginAt += this.connection.getAutoIncrementIncrement();
        }

    }

    ResultSetImpl gkRs = ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(rowSet), this.connection, this, false);

    this.openResults.add(gkRs);

    return gkRs;
  }

  protected int getId()
  {
    return this.statementId;
  }

  public long getLastInsertID()
  {
    return this.lastInsertId;
  }

  public long getLongUpdateCount()
  {
    if (this.results == null) {
      return -1L;
    }

    if (this.results.reallyResult()) {
      return -1L;
    }

    return this.updateCount;
  }

  public int getMaxFieldSize()
    throws SQLException
  {
    return this.maxFieldSize;
  }

  public int getMaxRows()
    throws SQLException
  {
    if (this.maxRows <= 0) {
      return 0;
    }

    return this.maxRows;
  }

  public boolean getMoreResults()
    throws SQLException
  {
    return getMoreResults(1);
  }

  public synchronized boolean getMoreResults(int current)
    throws SQLException
  {
    if (this.results == null) {
      return false;
    }

    boolean streamingMode = createStreamingResultSet();

    while ((streamingMode) && 
      (this.results.reallyResult()) && 
      (this.results.next()));
    ResultSetInternalMethods nextResultSet = this.results.getNextResultSet();

    switch (current)
    {
    case 1:
      if (this.results != null) {
        if (!(streamingMode)) {
          this.results.close();
        }

        this.results.clearNextResult(); } break;
    case 3:
      if (this.results != null) {
        if (!(streamingMode)) {
          this.results.close();
        }

        this.results.clearNextResult();
      }

      closeAllOpenResults();

      break;
    case 2:
      if (!(this.connection.getDontTrackOpenResources())) {
        this.openResults.add(this.results);
      }

      this.results.clearNextResult();

      break;
    default:
      throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", getExceptionInterceptor());
    }

    this.results = nextResultSet;

    if (this.results == null) {
      this.updateCount = -1L;
      this.lastInsertId = -1L;
    } else if (this.results.reallyResult()) {
      this.updateCount = -1L;
      this.lastInsertId = -1L;
    } else {
      this.updateCount = this.results.getUpdateCount();
      this.lastInsertId = this.results.getUpdateID();
    }

    return ((this.results != null) && (this.results.reallyResult()));
  }

  public int getQueryTimeout()
    throws SQLException
  {
    return (this.timeoutInMillis / 1000);
  }

  private int getRecordCountFromInfo(String serverInfo)
  {
    StringBuffer recordsBuf = new StringBuffer();
    int recordsCount = 0;
    int duplicatesCount = 0;

    char c = ';

    int length = serverInfo.length();
    int i = 0;

    for (; i < length; ++i) {
      c = serverInfo.charAt(i);

      if (Character.isDigit(c))
        break;

    }

    recordsBuf.append(c);
    ++i;

    for (; i < length; ++i) {
      c = serverInfo.charAt(i);

      if (!(Character.isDigit(c))) {
        break;
      }

      recordsBuf.append(c);
    }

    recordsCount = Integer.parseInt(recordsBuf.toString());

    StringBuffer duplicatesBuf = new StringBuffer();

    for (; i < length; ++i) {
      c = serverInfo.charAt(i);

      if (Character.isDigit(c))
        break;

    }

    duplicatesBuf.append(c);
    ++i;

    for (; i < length; ++i) {
      c = serverInfo.charAt(i);

      if (!(Character.isDigit(c))) {
        break;
      }

      duplicatesBuf.append(c);
    }

    duplicatesCount = Integer.parseInt(duplicatesBuf.toString());

    return (recordsCount - duplicatesCount);
  }

  public ResultSet getResultSet()
    throws SQLException
  {
    return (((this.results != null) && (this.results.reallyResult())) ? this.results : null);
  }

  public int getResultSetConcurrency()
    throws SQLException
  {
    return this.resultSetConcurrency;
  }

  public int getResultSetHoldability()
    throws SQLException
  {
    return 1;
  }

  protected ResultSetInternalMethods getResultSetInternal() {
    return this.results;
  }

  public int getResultSetType()
    throws SQLException
  {
    return this.resultSetType;
  }

  public int getUpdateCount()
    throws SQLException
  {
    if (this.results == null) {
      return -1;
    }

    if (this.results.reallyResult()) {
      return -1;
    }

    int truncatedUpdateCount = 0;

    if (this.results.getUpdateCount() > 2147483647L)
      truncatedUpdateCount = 2147483647;
    else {
      truncatedUpdateCount = (int)this.results.getUpdateCount();
    }

    return truncatedUpdateCount;
  }

  public SQLWarning getWarnings()
    throws SQLException
  {
    checkClosed();

    if ((this.connection != null) && (!(this.connection.isClosed())) && (this.connection.versionMeetsMinimum(4, 1, 0)))
    {
      SQLWarning pendingWarningsFromServer = SQLError.convertShowWarningsToSQLWarnings(this.connection);

      if (this.warningChain != null)
        this.warningChain.setNextWarning(pendingWarningsFromServer);
      else {
        this.warningChain = pendingWarningsFromServer;
      }

      return this.warningChain;
    }

    return this.warningChain;
  }

  protected synchronized void realClose(boolean calledExplicitly, boolean closeOpenResults)
    throws SQLException
  {
    if (this.isClosed) {
      return;
    }

    if ((this.useUsageAdvisor) && 
      (!(calledExplicitly))) {
      String message = Messages.getString("Statement.63") + Messages.getString("Statement.64");

      this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
    }

    if (closeOpenResults) {
      closeOpenResults = !(this.holdResultsOpenOverClose);
    }

    if (closeOpenResults) {
      if (this.results != null)
        try
        {
          this.results.close();
        }
        catch (Exception ex)
        {
        }

      closeAllOpenResults();
    }

    if (this.connection != null) {
      if (this.maxRowsChanged) {
        this.connection.unsetMaxRows(this);
      }

      if (!(this.connection.getDontTrackOpenResources()))
        this.connection.unregisterStatement(this);

    }

    this.isClosed = true;

    this.results = null;
    this.connection = null;
    this.warningChain = null;
    this.openResults = null;
    this.batchedGeneratedKeys = null;
    this.localInfileInputStream = null;
    this.pingTarget = null;
  }

  public void setCursorName(String name)
    throws SQLException
  {
  }

  public void setEscapeProcessing(boolean enable)
    throws SQLException
  {
    this.doEscapeProcessing = enable;
  }

  public void setFetchDirection(int direction)
    throws SQLException
  {
    switch (direction)
    {
    case 1000:
    case 1001:
    case 1002:
      break;
    default:
      throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor());
    }
  }

  public void setFetchSize(int rows)
    throws SQLException
  {
    if (((rows < 0) && (rows != -2147483648)) || ((this.maxRows != 0) && (this.maxRows != -1) && (rows > getMaxRows())))
    {
      throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());
    }

    this.fetchSize = rows;
  }

  protected void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) {
    this.holdResultsOpenOverClose = holdResultsOpenOverClose;
  }

  public void setMaxFieldSize(int max)
    throws SQLException
  {
    if (max < 0) {
      throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());
    }

    int maxBuf = (this.connection != null) ? this.connection.getMaxAllowedPacket() : MysqlIO.getMaxBuf();

    if (max > maxBuf) {
      throw SQLError.createSQLException(Messages.getString("Statement.13", new java.lang.Object[] { Constants.longValueOf(maxBuf) }), "S1009", getExceptionInterceptor());
    }

    this.maxFieldSize = max;
  }

  public void setMaxRows(int max)
    throws SQLException
  {
    if ((max > 50000000) || (max < 0)) {
      throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009", getExceptionInterceptor());
    }

    if (max == 0) {
      max = -1;
    }

    this.maxRows = max;
    this.maxRowsChanged = true;

    if (this.maxRows == -1) {
      this.connection.unsetMaxRows(this);
      this.maxRowsChanged = false;
    }
    else
    {
      this.connection.maxRowsChanged(this);
    }
  }

  public void setQueryTimeout(int seconds)
    throws SQLException
  {
    if (seconds < 0) {
      throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());
    }

    this.timeoutInMillis = (seconds * 1000);
  }

  void setResultSetConcurrency(int concurrencyFlag)
  {
    this.resultSetConcurrency = concurrencyFlag;
  }

  void setResultSetType(int typeFlag)
  {
    this.resultSetType = typeFlag;
  }

  protected void getBatchedGeneratedKeys(Statement batchedStatement) throws SQLException {
    if (this.retrieveGeneratedKeys) {
      ResultSet rs = null;
      try
      {
        rs = batchedStatement.getGeneratedKeys();

        while (rs.next())
          this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
      }
      finally
      {
        if (rs != null)
          rs.close();
      }
    }
  }

  protected void getBatchedGeneratedKeys(int maxKeys) throws SQLException
  {
    if (this.retrieveGeneratedKeys) {
      ResultSet rs = null;
      try
      {
        if (maxKeys == 0)
          rs = getGeneratedKeysInternal();
        else
          rs = getGeneratedKeysInternal(maxKeys);

        while (rs.next())
          this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
      }
      finally
      {
        if (rs != null)
          rs.close();
      }
    }
  }

  private boolean useServerFetch()
    throws SQLException
  {
    return ((this.connection.isCursorFetchEnabled()) && (this.fetchSize > 0) && (this.resultSetConcurrency == 1007) && (this.resultSetType == 1003));
  }

  public synchronized boolean isClosed()
    throws SQLException
  {
    return this.isClosed;
  }

  public boolean isPoolable()
    throws SQLException
  {
    return this.isPoolable;
  }

  public void setPoolable(boolean poolable) throws SQLException {
    this.isPoolable = poolable;
  }

  public boolean isWrapperFor(Class iface)
    throws SQLException
  {
    checkClosed();

    return iface.isInstance(this);
  }

  public java.lang.Object unwrap(Class iface)
    throws SQLException
  {
    try
    {
      return Util.cast(iface, this);
    } catch (ClassCastException cce) {
      throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
    }
  }

  protected int findStartOfStatement(String sql)
  {
    int statementStartPos = 0;

    if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*")) {
      statementStartPos = sql.indexOf("*/");

      if (statementStartPos == -1)
        statementStartPos = 0;
      else
        statementStartPos += 2;
    }
    else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "--")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "#")))
    {
      statementStartPos = sql.indexOf(10);

      if (statementStartPos == -1) {
        statementStartPos = sql.indexOf(13);

        if (statementStartPos == -1)
          statementStartPos = 0;
      }

    }

    return statementStartPos;
  }

  public synchronized InputStream getLocalInfileInputStream()
  {
    return this.localInfileInputStream;
  }

  public synchronized void setLocalInfileInputStream(InputStream stream) {
    this.localInfileInputStream = stream;
  }

  public synchronized void setPingTarget(PingTarget pingTarget) {
    this.pingTarget = pingTarget;
  }

  public ExceptionInterceptor getExceptionInterceptor() {
    return this.exceptionInterceptor;
  }

  protected boolean containsOnDuplicateKeyInString(String sql) {
    return (getOnDuplicateKeyLocation(sql) != -1);
  }

  protected int getOnDuplicateKeyLocation(String sql) {
    return StringUtils.indexOfIgnoreCaseRespectMarker(0, sql, " ON DUPLICATE KEY UPDATE ", "\"'`", "\"'`", !(this.connection.isNoBackslashEscapesSet()));
  }

  class CancelTask extends TimerTask
  {
    long connectionId;
    SQLException caughtWhileCancelling;
    StatementImpl toCancel;
    private final StatementImpl this$0;

    CancelTask(, StatementImpl cancellee)
      throws SQLException
    {
      this.this$0 = this$0;

      this.connectionId = 0L;
      this.caughtWhileCancelling = null;

      this.connectionId = this$0.connection.getIO().getThreadId();
      this.toCancel = cancellee;
    }

    public void run()
    {
      Thread cancelThread = new StatementImpl.1(this);

      cancelThread.start();
    }

    static StatementImpl access$000(CancelTask x0)
    {
      return x0.this$0;
    }
  }
}