package com.mysql.jdbc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.SQLException;
import java.sql.SQLXML;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class JDBC4MysqlSQLXML
  implements SQLXML
{
  private XMLInputFactory inputFactory;
  private XMLOutputFactory outputFactory;
  private String stringRep;
  private ResultSetInternalMethods owningResultSet;
  private int columnIndexOfXml;
  private boolean fromResultSet;
  private boolean isClosed = false;
  private boolean workingWithResult;
  private DOMResult asDOMResult;
  private SAXResult asSAXResult;
  private SimpleSaxToReader saxToReaderConverter;
  private StringWriter asStringWriter;
  private ByteArrayOutputStream asByteArrayOutputStream;
  private ExceptionInterceptor exceptionInterceptor;

  protected JDBC4MysqlSQLXML(ResultSetInternalMethods owner, int index, ExceptionInterceptor exceptionInterceptor)
  {
    this.owningResultSet = owner;
    this.columnIndexOfXml = index;
    this.fromResultSet = true;
    this.exceptionInterceptor = exceptionInterceptor;
  }

  protected JDBC4MysqlSQLXML(ExceptionInterceptor exceptionInterceptor) {
    this.fromResultSet = false;
    this.exceptionInterceptor = exceptionInterceptor;
  }

  public synchronized void free() throws SQLException {
    this.stringRep = null;
    this.asDOMResult = null;
    this.asSAXResult = null;
    this.inputFactory = null;
    this.outputFactory = null;
    this.owningResultSet = null;
    this.workingWithResult = false;
    this.isClosed = true;
  }

  public synchronized String getString() throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    if (this.fromResultSet) {
      return this.owningResultSet.getString(this.columnIndexOfXml);
    }

    return this.stringRep;
  }

  private synchronized void checkClosed() throws SQLException {
    if (this.isClosed)
      throw SQLError.createSQLException("SQLXMLInstance has been free()d", this.exceptionInterceptor);
  }

  private synchronized void checkWorkingWithResult()
    throws SQLException
  {
    if (this.workingWithResult)
      throw SQLError.createSQLException("Can't perform requested operation after getResult() has been called to write XML data", "S1009", this.exceptionInterceptor);
  }

  public synchronized void setString(String str)
    throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    this.stringRep = str;
    this.fromResultSet = false;
  }

  public synchronized boolean isEmpty() throws SQLException {
    checkClosed();
    checkWorkingWithResult();

    if (!(this.fromResultSet)) {
      return ((this.stringRep == null) || (this.stringRep.length() == 0));
    }

    return false;
  }

  public synchronized InputStream getBinaryStream() throws SQLException {
    checkClosed();
    checkWorkingWithResult();

    return this.owningResultSet.getBinaryStream(this.columnIndexOfXml);
  }

  public synchronized Reader getCharacterStream()
    throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    return this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
  }

  public synchronized Source getSource(Class clazz)
    throws SQLException
  {
    Reader reader;
    SQLException sqlEx;
    checkClosed();
    checkWorkingWithResult();

    if ((clazz == null) || (clazz.equals(SAXSource.class)))
    {
      InputSource inputSource = null;

      if (this.fromResultSet) {
        inputSource = new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml));
      }
      else {
        inputSource = new InputSource(new StringReader(this.stringRep));
      }

      return new SAXSource(inputSource); }
    if (clazz.equals(DOMSource.class))
      try {
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();

        builderFactory.setNamespaceAware(true);
        DocumentBuilder builder = builderFactory.newDocumentBuilder();

        InputSource inputSource = null;

        if (this.fromResultSet) {
          inputSource = new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml));
        }
        else {
          inputSource = new InputSource(new StringReader(this.stringRep));
        }

        return new DOMSource(builder.parse(inputSource));
      } catch (Throwable t) {
        sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", this.exceptionInterceptor);

        sqlEx.initCause(t);

        throw sqlEx;
      }

    if (clazz.equals(StreamSource.class)) {
      reader = null;

      if (this.fromResultSet) {
        reader = this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
      }
      else {
        reader = new StringReader(this.stringRep);
      }

      return new StreamSource(reader); }
    if (clazz.equals(StAXSource.class))
      try {
        reader = null;

        if (this.fromResultSet) {
          reader = this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
        }
        else {
          reader = new StringReader(this.stringRep);
        }

        return new StAXSource(this.inputFactory.createXMLStreamReader(reader));
      }
      catch (XMLStreamException ex) {
        sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", this.exceptionInterceptor);

        sqlEx.initCause(ex);

        throw sqlEx;
      }

    throw SQLError.createSQLException("XML Source of type \"" + clazz.toString() + "\" Not supported.", "S1009", this.exceptionInterceptor);
  }

  public synchronized OutputStream setBinaryStream()
    throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    this.workingWithResult = true;

    return setBinaryStreamInternal();
  }

  private synchronized OutputStream setBinaryStreamInternal() throws SQLException
  {
    this.asByteArrayOutputStream = new ByteArrayOutputStream();

    return this.asByteArrayOutputStream;
  }

  public synchronized Writer setCharacterStream()
    throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    this.workingWithResult = true;

    return setCharacterStreamInternal();
  }

  private synchronized Writer setCharacterStreamInternal() throws SQLException
  {
    this.asStringWriter = new StringWriter();

    return this.asStringWriter;
  }

  public synchronized Result setResult(Class clazz)
    throws SQLException
  {
    checkClosed();
    checkWorkingWithResult();

    this.workingWithResult = true;
    this.asDOMResult = null;
    this.asSAXResult = null;
    this.saxToReaderConverter = null;
    this.stringRep = null;
    this.asStringWriter = null;
    this.asByteArrayOutputStream = null;

    if ((clazz == null) || (clazz.equals(SAXResult.class))) {
      this.saxToReaderConverter = new SimpleSaxToReader(this);

      this.asSAXResult = new SAXResult(this.saxToReaderConverter);

      return this.asSAXResult; }
    if (clazz.equals(DOMResult.class))
    {
      this.asDOMResult = new DOMResult();
      return this.asDOMResult;
    }
    if (clazz.equals(StreamResult.class))
      return new StreamResult(setCharacterStreamInternal());
    if (clazz.equals(StAXResult.class))
      try {
        if (this.outputFactory == null) {
          this.outputFactory = XMLOutputFactory.newInstance();
        }

        return new StAXResult(this.outputFactory.createXMLEventWriter(setCharacterStreamInternal()));
      }
      catch (XMLStreamException ex) {
        SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", this.exceptionInterceptor);

        sqlEx.initCause(ex);

        throw sqlEx;
      }

    throw SQLError.createSQLException("XML Result of type \"" + clazz.toString() + "\" Not supported.", "S1009", this.exceptionInterceptor); } 
  // ERROR //
  private Reader binaryInputStreamStreamToReader(ByteArrayOutputStream out) { // Byte code:
    //   0: ldc 76
    //   2: astore_2
    //   3: new 77	java/io/ByteArrayInputStream
    //   6: dup
    //   7: aload_1
    //   8: invokevirtual 78	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   11: invokespecial 79	java/io/ByteArrayInputStream:<init>	([B)V
    //   14: astore_3
    //   15: aload_0
    //   16: getfield 10	com/mysql/jdbc/JDBC4MysqlSQLXML:inputFactory	Ljavax/xml/stream/XMLInputFactory;
    //   19: aload_3
    //   20: invokevirtual 80	javax/xml/stream/XMLInputFactory:createXMLStreamReader	(Ljava/io/InputStream;)Ljavax/xml/stream/XMLStreamReader;
    //   23: astore 4
    //   25: iconst_0
    //   26: istore 5
    //   28: aload 4
    //   30: invokeinterface 81 1 0
    //   35: dup
    //   36: istore 5
    //   38: bipush 8
    //   40: if_icmpeq +30 -> 70
    //   43: iload 5
    //   45: bipush 7
    //   47: if_icmpne -19 -> 28
    //   50: aload 4
    //   52: invokeinterface 82 1 0
    //   57: astore 6
    //   59: aload 6
    //   61: ifnull +9 -> 70
    //   64: aload 6
    //   66: astore_2
    //   67: goto +3 -> 70
    //   70: goto +4 -> 74
    //   73: astore_3
    //   74: new 28	java/io/StringReader
    //   77: dup
    //   78: new 83	java/lang/String
    //   81: dup
    //   82: aload_1
    //   83: invokevirtual 78	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   86: aload_2
    //   87: invokespecial 84	java/lang/String:<init>	([BLjava/lang/String;)V
    //   90: invokespecial 29	java/io/StringReader:<init>	(Ljava/lang/String;)V
    //   93: areturn
    //   94: astore_2
    //   95: new 86	java/lang/RuntimeException
    //   98: dup
    //   99: aload_2
    //   100: invokespecial 87	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   103: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	70	73	java/lang/Throwable
    //   0	93	94	java/io/UnsupportedEncodingException } 
  protected String readerToString(Reader reader) throws SQLException { java.lang.StringBuffer buf = new java.lang.StringBuffer();

    int charsRead = 0;

    char[] charBuf = new char[512];
    try
    {
      while ((charsRead = reader.read(charBuf)) != -1)
        buf.append(charBuf, 0, charsRead);
    }
    catch (IOException ioEx) {
      SQLException sqlEx = SQLError.createSQLException(ioEx.getMessage(), "S1009", this.exceptionInterceptor);

      sqlEx.initCause(ioEx);

      throw sqlEx;
    }

    return buf.toString();
  }

  protected synchronized Reader serializeAsCharacterStream() throws SQLException
  {
    checkClosed();
    if (this.workingWithResult)
    {
      if (this.stringRep != null) {
        return new StringReader(this.stringRep);
      }

      if (this.asDOMResult != null) {
        return new StringReader(domSourceToString());
      }

      if (this.asStringWriter != null) {
        return new StringReader(this.asStringWriter.toString());
      }

      if (this.asSAXResult != null) {
        return this.saxToReaderConverter.toReader();
      }

      if (this.asByteArrayOutputStream != null)
        return binaryInputStreamStreamToReader(this.asByteArrayOutputStream);

    }

    return this.owningResultSet.getCharacterStream(this.columnIndexOfXml); }

  protected String domSourceToString() throws SQLException {
    DOMSource source;
    try {
      source = new DOMSource(this.asDOMResult.getNode());
      Transformer identity = TransformerFactory.newInstance().newTransformer();

      StringWriter stringOut = new StringWriter();
      Result result = new StreamResult(stringOut);
      identity.transform(source, result);

      return stringOut.toString();
    } catch (Throwable t) {
      SQLException sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", this.exceptionInterceptor);

      sqlEx.initCause(t);

      throw sqlEx;
    }
  }

  protected synchronized String serializeAsString() throws SQLException {
    checkClosed();
    if (this.workingWithResult)
    {
      if (this.stringRep != null) {
        return this.stringRep;
      }

      if (this.asDOMResult != null) {
        return domSourceToString();
      }

      if (this.asStringWriter != null) {
        return this.asStringWriter.toString();
      }

      if (this.asSAXResult != null) {
        return readerToString(this.saxToReaderConverter.toReader());
      }

      if (this.asByteArrayOutputStream != null) {
        return readerToString(binaryInputStreamStreamToReader(this.asByteArrayOutputStream));
      }

    }

    return this.owningResultSet.getString(this.columnIndexOfXml);
  }

  class SimpleSaxToReader extends DefaultHandler
  {
    java.lang.StringBuffer buf;
    private boolean inCDATA;

    SimpleSaxToReader()
    {
      this.buf = new java.lang.StringBuffer();

      this.inCDATA = false;
    }

    public void startDocument()
      throws SAXException
    {
      this.buf.append("<?xml version='1.0' encoding='UTF-8'?>");
    }

    public void endDocument()
      throws SAXException
    {
    }

    public void startElement(, String sName, String qName, Attributes attrs) throws SAXException
    {
      int i;
      this.buf.append("<");
      this.buf.append(qName);

      if (attrs != null)
        for (i = 0; i < attrs.getLength(); ++i) {
          this.buf.append(" ");
          this.buf.append(attrs.getQName(i)).append("=\"");
          escapeCharsForXml(attrs.getValue(i), true);
          this.buf.append("\"");
        }


      this.buf.append(">");
    }

    public void characters(, int offset, int len) throws SAXException
    {
      if (!(this.inCDATA))
        escapeCharsForXml(buf, offset, len, false);
      else
        this.buf.append(buf, offset, len);
    }

    public void ignorableWhitespace(, int start, int length)
      throws SAXException
    {
      characters(ch, start, length);
    }

    public void startCDATA()
      throws SAXException
    {
      this.buf.append("<![CDATA[");
      this.inCDATA = true;
    }

    public void endCDATA() throws SAXException {
      this.inCDATA = false;
      this.buf.append("]]>");
    }

    public void comment(, int start, int length)
      throws SAXException
    {
      this.buf.append("<!--");
      for (int i = 0; i < length; ++i)
        this.buf.append(ch[(start + i)]);

      this.buf.append("-->");
    }

    Reader toReader()
    {
      return new StringReader(this.buf.toString());
    }

    private void escapeCharsForXml(, boolean isAttributeData) {
      if (str == null) {
        return;
      }

      int strLen = str.length();

      for (int i = 0; i < strLen; ++i)
        escapeCharsForXml(str.charAt(i), isAttributeData);
    }

    private void escapeCharsForXml(, int offset, int len, boolean isAttributeData)
    {
      if (buf == null) {
        return;
      }

      for (int i = 0; i < len; ++i)
        escapeCharsForXml(buf[(offset + i)], isAttributeData);
    }

    private void escapeCharsForXml(, boolean isAttributeData)
    {
      switch (c)
      {
      case '<':
        this.buf.append("&lt;");
        break;
      case '>':
        this.buf.append("&gt;");
        break;
      case '&':
        this.buf.append("&amp;");
        break;
      case '"':
        if (!(isAttributeData)) {
          this.buf.append("\""); return;
        }

        this.buf.append("&quot;");

        break;
      case '\r':
        this.buf.append("&#xD;");
        break;
      default:
        if (((c >= '\1') && (c <= '\31') && (c != '\t') && (c != '\n')) || ((c >= '') && (c <= 159)) || (c == 8232) || ((isAttributeData) && (((c == '\t') || (c == '\n')))))
        {
          this.buf.append("&#x");
          this.buf.append(Integer.toHexString(c).toUpperCase());
          this.buf.append(";"); return;
        }

        this.buf.append(c);
      }
    }
  }
}