package com.mysql.jdbc;

import com.mysql.jdbc.profiler.ProfilerEvent;
import com.mysql.jdbc.profiler.ProfilerEventHandler;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.ParameterMetaData;
import java.sql.Ref;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

public class ServerPreparedStatement extends PreparedStatement
{
  private static final java.lang.reflect.Constructor JDBC_4_SPS_CTOR;
  protected static final int BLOB_STREAM_READ_BUF_SIZE = 8192;
  private static final byte MAX_DATE_REP_LENGTH = 5;
  private static final byte MAX_DATETIME_REP_LENGTH = 12;
  private static final byte MAX_TIME_REP_LENGTH = 13;
  private boolean hasOnDuplicateKeyUpdate = false;
  private boolean detectedLongParameterSwitch = false;
  private int fieldCount;
  private boolean invalid = false;
  private SQLException invalidationException;
  private boolean isSelectQuery;
  private Buffer outByteBuffer;
  private BindValue[] parameterBindings;
  private Field[] parameterFields;
  private Field[] resultFields;
  private boolean sendTypesToServer = false;
  private long serverStatementId;
  private int stringTypeCode = 254;
  private boolean serverNeedsResetBeforeEachExecution;
  protected boolean isCached = false;
  private boolean useAutoSlowLog;
  private Calendar serverTzCalendar;
  private Calendar defaultTzCalendar;
  private boolean hasCheckedRewrite = false;
  private boolean canRewrite = false;
  private int locationOfOnDuplicateKeyUpdate = -2;

  private void storeTime(Buffer intoBuf, Time tm)
    throws SQLException
  {
    intoBuf.ensureCapacity(9);
    intoBuf.writeByte(8);
    intoBuf.writeByte(0);
    intoBuf.writeLong(0L);

    Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();

    synchronized (sessionCalendar) {
      Date oldTime = sessionCalendar.getTime();
      try {
        sessionCalendar.setTime(tm);
        intoBuf.writeByte((byte)sessionCalendar.get(11));
        intoBuf.writeByte((byte)sessionCalendar.get(12));
        intoBuf.writeByte((byte)sessionCalendar.get(13));
      }
      finally
      {
        sessionCalendar.setTime(oldTime);
      }
    }
  }

  protected static ServerPreparedStatement getInstance(ConnectionImpl conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    if (!(Util.isJdbc4())) {
      return new ServerPreparedStatement(conn, sql, catalog, resultSetType, resultSetConcurrency);
    }

    try
    {
      return ((ServerPreparedStatement)JDBC_4_SPS_CTOR.newInstance(new Object[] { conn, sql, catalog, Constants.integerValueOf(resultSetType), Constants.integerValueOf(resultSetConcurrency) }));
    }
    catch (IllegalArgumentException e)
    {
      throw new SQLException(e.toString(), "S1000");
    } catch (InstantiationException e) {
      throw new SQLException(e.toString(), "S1000");
    } catch (IllegalAccessException e) {
      throw new SQLException(e.toString(), "S1000");
    } catch (InvocationTargetException e) {
      Throwable target = e.getTargetException();

      if (target instanceof SQLException) {
        throw ((SQLException)target);
      }

      throw new SQLException(target.toString(), "S1000");
    }
  }

  protected ServerPreparedStatement(ConnectionImpl conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    super(conn, catalog);

    checkNullOrEmptyQuery(sql);

    this.hasOnDuplicateKeyUpdate = containsOnDuplicateKeyInString(sql);

    int startOfStatement = findStartOfStatement(sql);

    this.firstCharOfStmt = StringUtils.firstAlphaCharUc(sql, startOfStatement);

    this.isSelectQuery = ('S' == this.firstCharOfStmt);

    if (this.connection.versionMeetsMinimum(5, 0, 0)) {
      this.serverNeedsResetBeforeEachExecution = (!(this.connection.versionMeetsMinimum(5, 0, 3)));
    }
    else {
      this.serverNeedsResetBeforeEachExecution = (!(this.connection.versionMeetsMinimum(4, 1, 10)));
    }

    this.useAutoSlowLog = this.connection.getAutoSlowLog();
    this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
    this.hasLimitClause = (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1);

    String statementComment = this.connection.getStatementComment();

    this.originalSql = "/* " + statementComment + " */ " + sql;

    if (this.connection.versionMeetsMinimum(4, 1, 2))
      this.stringTypeCode = 253;
    else
      this.stringTypeCode = 254;

    try
    {
      serverPrepare(sql);
    } catch (SQLException sqlEx) {
      realClose(false, true);

      throw sqlEx;
    } catch (Exception ex) {
      realClose(false, true);

      SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());

      sqlEx.initCause(ex);

      throw sqlEx;
    }

    setResultSetType(resultSetType);
    setResultSetConcurrency(resultSetConcurrency);

    this.parameterTypes = new int[this.parameterCount];
  }

  public synchronized void addBatch()
    throws SQLException
  {
    checkClosed();

    if (this.batchedArgs == null) {
      this.batchedArgs = new ArrayList();
    }

    this.batchedArgs.add(new BatchedBindValues(this.parameterBindings));
  }

  protected String asSql(boolean quoteStreamsAndUnknowns) throws SQLException
  {
    if (this.isClosed) {
      return "statement has been closed, no further internal information available";
    }

    PreparedStatement pStmtForSub = null;
    try
    {
      pStmtForSub = PreparedStatement.getInstance(this.connection, this.originalSql, this.currentCatalog);

      int numParameters = pStmtForSub.parameterCount;
      int ourNumParameters = this.parameterCount;

      for (int i = 0; (i < numParameters) && (i < ourNumParameters); ++i) {
        if (this.parameterBindings[i] != null)
          if (this.parameterBindings[i].isNull) {
            pStmtForSub.setNull(i + 1, 0);
          } else {
            BindValue bindValue = this.parameterBindings[i];

            switch (bindValue.bufferType)
            {
            case 1:
              pStmtForSub.setByte(i + 1, bindValue.byteBinding);
              break;
            case 2:
              pStmtForSub.setShort(i + 1, bindValue.shortBinding);
              break;
            case 3:
              pStmtForSub.setInt(i + 1, bindValue.intBinding);
              break;
            case 8:
              pStmtForSub.setLong(i + 1, bindValue.longBinding);
              break;
            case 4:
              pStmtForSub.setFloat(i + 1, bindValue.floatBinding);
              break;
            case 5:
              pStmtForSub.setDouble(i + 1, bindValue.doubleBinding);

              break;
            case 6:
            case 7:
            default:
              pStmtForSub.setObject(i + 1, this.parameterBindings[i].value);
            }

          }


      }

      return pStmtForSub.asSql(quoteStreamsAndUnknowns);
    } finally {
      if (pStmtForSub != null)
        try {
          pStmtForSub.close();
        }
        catch (SQLException sqlEx)
        {
        }
    }
  }

  protected void checkClosed()
    throws SQLException
  {
    if (this.invalid) {
      throw this.invalidationException;
    }

    super.checkClosed();
  }

  public void clearParameters()
    throws SQLException
  {
    checkClosed();
    clearParametersInternal(true);
  }

  private void clearParametersInternal(boolean clearServerParameters) throws SQLException
  {
    int i;
    boolean hadLongData = false;

    if (this.parameterBindings != null)
      for (i = 0; i < this.parameterCount; ++i) {
        if ((this.parameterBindings[i] != null) && (this.parameterBindings[i].isLongData))
        {
          hadLongData = true;
        }

        this.parameterBindings[i].reset();
      }


    if ((clearServerParameters) && (hadLongData)) {
      serverResetStatement();

      this.detectedLongParameterSwitch = false;
    }
  }

  protected void setClosed(boolean flag)
  {
    this.isClosed = flag;
  }

  public synchronized void close()
    throws SQLException
  {
    if ((this.isCached) && (!(this.isClosed))) {
      clearParameters();

      this.isClosed = true;

      this.connection.recachePreparedStatement(this);
      return;
    }

    realClose(true, true);
  }

  private void dumpCloseForTestcase() {
    StringBuffer buf = new StringBuffer();
    this.connection.generateConnectionCommentBlock(buf);
    buf.append("DEALLOCATE PREPARE debug_stmt_");
    buf.append(this.statementId);
    buf.append(";\n");

    this.connection.dumpTestcaseQuery(buf.toString());
  }

  private void dumpExecuteForTestcase() throws SQLException {
    StringBuffer buf = new StringBuffer();

    for (int i = 0; i < this.parameterCount; ++i) {
      this.connection.generateConnectionCommentBlock(buf);

      buf.append("SET @debug_stmt_param");
      buf.append(this.statementId);
      buf.append("_");
      buf.append(i);
      buf.append("=");

      if (this.parameterBindings[i].isNull)
        buf.append("NULL");
      else {
        buf.append(this.parameterBindings[i].toString(true));
      }

      buf.append(";\n");
    }

    this.connection.generateConnectionCommentBlock(buf);

    buf.append("EXECUTE debug_stmt_");
    buf.append(this.statementId);

    if (this.parameterCount > 0) {
      buf.append(" USING ");
      for (i = 0; i < this.parameterCount; ++i) {
        if (i > 0) {
          buf.append(", ");
        }

        buf.append("@debug_stmt_param");
        buf.append(this.statementId);
        buf.append("_");
        buf.append(i);
      }

    }

    buf.append(";\n");

    this.connection.dumpTestcaseQuery(buf.toString());
  }

  private void dumpPrepareForTestcase() throws SQLException
  {
    StringBuffer buf = new StringBuffer(this.originalSql.length() + 64);

    this.connection.generateConnectionCommentBlock(buf);

    buf.append("PREPARE debug_stmt_");
    buf.append(this.statementId);
    buf.append(" FROM \"");
    buf.append(this.originalSql);
    buf.append("\";\n");

    this.connection.dumpTestcaseQuery(buf.toString()); } 
  // ERROR //
  protected int[] executeBatchSerially(int batchTimeout) throws SQLException { // Byte code:
    //   0: aload_0
    //   1: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnonnull +7 -> 13
    //   9: aload_0
    //   10: invokevirtual 76	com/mysql/jdbc/ServerPreparedStatement:checkClosed	()V
    //   13: aload_2
    //   14: invokevirtual 136	com/mysql/jdbc/ConnectionImpl:isReadOnly	()Z
    //   17: ifeq +39 -> 56
    //   20: new 58	java/lang/StringBuffer
    //   23: dup
    //   24: invokespecial 59	java/lang/StringBuffer:<init>	()V
    //   27: ldc 137
    //   29: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   32: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   35: ldc 139
    //   37: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   40: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   43: invokevirtual 63	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   46: ldc 140
    //   48: aload_0
    //   49: invokevirtual 69	com/mysql/jdbc/ServerPreparedStatement:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
    //   52: invokestatic 70	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   55: athrow
    //   56: aload_0
    //   57: invokevirtual 76	com/mysql/jdbc/ServerPreparedStatement:checkClosed	()V
    //   60: aload_2
    //   61: invokevirtual 141	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   64: dup
    //   65: astore_3
    //   66: monitorenter
    //   67: aload_0
    //   68: invokevirtual 142	com/mysql/jdbc/ServerPreparedStatement:clearWarnings	()V
    //   71: aload_0
    //   72: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   75: astore 4
    //   77: aconst_null
    //   78: astore 5
    //   80: aload_0
    //   81: getfield 77	com/mysql/jdbc/ServerPreparedStatement:batchedArgs	Ljava/util/List;
    //   84: ifnull +518 -> 602
    //   87: aload_0
    //   88: getfield 77	com/mysql/jdbc/ServerPreparedStatement:batchedArgs	Ljava/util/List;
    //   91: invokeinterface 143 1 0
    //   96: istore 6
    //   98: iload 6
    //   100: newarray int
    //   102: astore 5
    //   104: aload_0
    //   105: getfield 144	com/mysql/jdbc/ServerPreparedStatement:retrieveGeneratedKeys	Z
    //   108: ifeq +16 -> 124
    //   111: aload_0
    //   112: new 78	java/util/ArrayList
    //   115: dup
    //   116: iload 6
    //   118: invokespecial 145	java/util/ArrayList:<init>	(I)V
    //   121: putfield 146	com/mysql/jdbc/ServerPreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
    //   124: iconst_0
    //   125: istore 7
    //   127: iload 7
    //   129: iload 6
    //   131: if_icmpge +16 -> 147
    //   134: aload 5
    //   136: iload 7
    //   138: bipush 253
    //   140: iastore
    //   141: iinc 7 1
    //   144: goto -17 -> 127
    //   147: aconst_null
    //   148: astore 7
    //   150: iconst_0
    //   151: istore 8
    //   153: aconst_null
    //   154: astore 9
    //   156: aconst_null
    //   157: astore 10
    //   159: aload_2
    //   160: invokevirtual 147	com/mysql/jdbc/ConnectionImpl:getEnableQueryTimeouts	()Z
    //   163: ifeq +38 -> 201
    //   166: iload_1
    //   167: ifeq +34 -> 201
    //   170: aload_2
    //   171: iconst_5
    //   172: iconst_0
    //   173: iconst_0
    //   174: invokevirtual 49	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
    //   177: ifeq +24 -> 201
    //   180: new 148	com/mysql/jdbc/StatementImpl$CancelTask
    //   183: dup
    //   184: aload_0
    //   185: aload_0
    //   186: invokespecial 149	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
    //   189: astore 10
    //   191: invokestatic 150	com/mysql/jdbc/ConnectionImpl:getCancelTimer	()Ljava/util/Timer;
    //   194: aload 10
    //   196: iload_1
    //   197: i2l
    //   198: invokevirtual 151	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
    //   201: iconst_0
    //   202: istore 8
    //   204: iload 8
    //   206: iload 6
    //   208: if_icmpge +331 -> 539
    //   211: aload_0
    //   212: getfield 77	com/mysql/jdbc/ServerPreparedStatement:batchedArgs	Ljava/util/List;
    //   215: iload 8
    //   217: invokeinterface 152 2 0
    //   222: astore 11
    //   224: aload 11
    //   226: instanceof 153
    //   229: ifeq +20 -> 249
    //   232: aload 5
    //   234: iload 8
    //   236: aload_0
    //   237: aload 11
    //   239: checkcast 153	java/lang/String
    //   242: invokevirtual 154	com/mysql/jdbc/ServerPreparedStatement:executeUpdate	(Ljava/lang/String;)I
    //   245: iastore
    //   246: goto +287 -> 533
    //   249: aload_0
    //   250: aload 11
    //   252: checkcast 80	com/mysql/jdbc/ServerPreparedStatement$BatchedBindValues
    //   255: getfield 155	com/mysql/jdbc/ServerPreparedStatement$BatchedBindValues:batchedParameterValues	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   258: putfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   261: aload 9
    //   263: ifnull +51 -> 314
    //   266: iconst_0
    //   267: istore 12
    //   269: iload 12
    //   271: aload_0
    //   272: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   275: arraylength
    //   276: if_icmpge +38 -> 314
    //   279: aload_0
    //   280: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   283: iload 12
    //   285: aaload
    //   286: getfield 91	com/mysql/jdbc/ServerPreparedStatement$BindValue:bufferType	I
    //   289: aload 9
    //   291: iload 12
    //   293: aaload
    //   294: getfield 91	com/mysql/jdbc/ServerPreparedStatement$BindValue:bufferType	I
    //   297: if_icmpeq +11 -> 308
    //   300: aload_0
    //   301: iconst_1
    //   302: putfield 36	com/mysql/jdbc/ServerPreparedStatement:sendTypesToServer	Z
    //   305: goto +9 -> 314
    //   308: iinc 12 1
    //   311: goto -42 -> 269
    //   314: aload 5
    //   316: iload 8
    //   318: aload_0
    //   319: iconst_0
    //   320: iconst_1
    //   321: invokevirtual 156	com/mysql/jdbc/ServerPreparedStatement:executeUpdate	(ZZ)I
    //   324: iastore
    //   325: aload_0
    //   326: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   329: astore 9
    //   331: goto +14 -> 345
    //   334: astore 13
    //   336: aload_0
    //   337: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   340: astore 9
    //   342: aload 13
    //   344: athrow
    //   345: aload_0
    //   346: getfield 144	com/mysql/jdbc/ServerPreparedStatement:retrieveGeneratedKeys	Z
    //   349: ifeq +91 -> 440
    //   352: aconst_null
    //   353: astore 12
    //   355: aload_0
    //   356: invokevirtual 157	com/mysql/jdbc/ServerPreparedStatement:getGeneratedKeysInternal	()Ljava/sql/ResultSet;
    //   359: astore 12
    //   361: aload 12
    //   363: invokeinterface 158 1 0
    //   368: ifeq +40 -> 408
    //   371: aload_0
    //   372: getfield 146	com/mysql/jdbc/ServerPreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
    //   375: new 159	com/mysql/jdbc/ByteArrayRow
    //   378: dup
    //   379: iconst_1
    //   380: anewarray 160	[B
    //   383: dup
    //   384: iconst_0
    //   385: aload 12
    //   387: iconst_1
    //   388: invokeinterface 161 2 0
    //   393: aastore
    //   394: aload_0
    //   395: invokevirtual 69	com/mysql/jdbc/ServerPreparedStatement:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
    //   398: invokespecial 162	com/mysql/jdbc/ByteArrayRow:<init>	([[BLcom/mysql/jdbc/ExceptionInterceptor;)V
    //   401: invokevirtual 163	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   404: pop
    //   405: goto -44 -> 361
    //   408: aload 12
    //   410: ifnull +30 -> 440
    //   413: aload 12
    //   415: invokeinterface 164 1 0
    //   420: goto +20 -> 440
    //   423: astore 14
    //   425: aload 12
    //   427: ifnull +10 -> 437
    //   430: aload 12
    //   432: invokeinterface 164 1 0
    //   437: aload 14
    //   439: athrow
    //   440: goto +93 -> 533
    //   443: astore 12
    //   445: aload 5
    //   447: iload 8
    //   449: bipush 253
    //   451: iastore
    //   452: aload_0
    //   453: getfield 165	com/mysql/jdbc/ServerPreparedStatement:continueBatchOnError	Z
    //   456: ifeq +35 -> 491
    //   459: aload 12
    //   461: instanceof 166
    //   464: ifne +27 -> 491
    //   467: aload 12
    //   469: instanceof 167
    //   472: ifne +19 -> 491
    //   475: aload_0
    //   476: aload 12
    //   478: invokevirtual 168	com/mysql/jdbc/ServerPreparedStatement:hasDeadlockOrTimeoutRolledBackTx	(Ljava/sql/SQLException;)Z
    //   481: ifne +10 -> 491
    //   484: aload 12
    //   486: astore 7
    //   488: goto +45 -> 533
    //   491: iload 8
    //   493: newarray int
    //   495: astore 13
    //   497: aload 5
    //   499: iconst_0
    //   500: aload 13
    //   502: iconst_0
    //   503: iload 8
    //   505: invokestatic 169	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   508: new 170	java/sql/BatchUpdateException
    //   511: dup
    //   512: aload 12
    //   514: invokevirtual 171	SQLException:getMessage	()Ljava/lang/String;
    //   517: aload 12
    //   519: invokevirtual 172	SQLException:getSQLState	()Ljava/lang/String;
    //   522: aload 12
    //   524: invokevirtual 173	SQLException:getErrorCode	()I
    //   527: aload 13
    //   529: invokespecial 174	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
    //   532: athrow
    //   533: iinc 8 1
    //   536: goto -332 -> 204
    //   539: jsr +14 -> 553
    //   542: goto +30 -> 572
    //   545: astore 15
    //   547: jsr +6 -> 553
    //   550: aload 15
    //   552: athrow
    //   553: astore 16
    //   555: aload 10
    //   557: ifnull +9 -> 566
    //   560: aload 10
    //   562: invokevirtual 175	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   565: pop
    //   566: aload_0
    //   567: invokevirtual 176	com/mysql/jdbc/ServerPreparedStatement:resetCancelledState	()V
    //   570: ret 16
    //   572: aload 7
    //   574: ifnull +28 -> 602
    //   577: new 170	java/sql/BatchUpdateException
    //   580: dup
    //   581: aload 7
    //   583: invokevirtual 171	SQLException:getMessage	()Ljava/lang/String;
    //   586: aload 7
    //   588: invokevirtual 172	SQLException:getSQLState	()Ljava/lang/String;
    //   591: aload 7
    //   593: invokevirtual 173	SQLException:getErrorCode	()I
    //   596: aload 5
    //   598: invokespecial 174	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
    //   601: athrow
    //   602: aload 5
    //   604: ifnull +8 -> 612
    //   607: aload 5
    //   609: goto +6 -> 615
    //   612: iconst_0
    //   613: newarray int
    //   615: astore 6
    //   617: jsr +16 -> 633
    //   620: aload_3
    //   621: monitorexit
    //   622: aload 6
    //   624: areturn
    //   625: astore 17
    //   627: jsr +6 -> 633
    //   630: aload 17
    //   632: athrow
    //   633: astore 18
    //   635: aload_0
    //   636: aload 4
    //   638: putfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   641: aload_0
    //   642: iconst_1
    //   643: putfield 36	com/mysql/jdbc/ServerPreparedStatement:sendTypesToServer	Z
    //   646: aload_0
    //   647: invokevirtual 177	com/mysql/jdbc/ServerPreparedStatement:clearBatch	()V
    //   650: ret 18
    //   652: astore 19
    //   654: aload_3
    //   655: monitorexit
    //   656: aload 19
    //   658: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   314	325	334	finally
    //   334	336	334	finally
    //   355	408	423	finally
    //   423	425	423	finally
    //   261	440	443	SQLException
    //   159	542	545	finally
    //   545	550	545	finally
    //   77	620	625	finally
    //   625	630	625	finally
    //   67	622	652	finally
    //   625	656	652	finally } 
  protected ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch) throws SQLException { this.numberOfExecutions += 1;
    try
    {
      return serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadataFromCache);
    }
    catch (SQLException sqlEx)
    {
      if (this.connection.getEnablePacketDebug()) {
        this.connection.getIO().dumpPacketRingBuffer();
      }

      if (this.connection.getDumpQueriesOnException()) {
        String extractedSql = toString();
        StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);

        messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");

        messageBuf.append(extractedSql);

        sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
      }

      throw sqlEx;
    } catch (Exception ex) {
      if (this.connection.getEnablePacketDebug()) {
        this.connection.getIO().dumpPacketRingBuffer();
      }

      SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());

      if (this.connection.getDumpQueriesOnException()) {
        String extractedSql = toString();
        StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);

        messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");

        messageBuf.append(extractedSql);

        sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
      }

      sqlEx.initCause(ex);

      throw sqlEx;
    }
  }

  protected Buffer fillSendPacket()
    throws SQLException
  {
    return null;
  }

  protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
    throws SQLException
  {
    return null;
  }

  protected BindValue getBinding(int parameterIndex, boolean forLongData)
    throws SQLException
  {
    checkClosed();

    if (this.parameterBindings.length == 0) {
      throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.8"), "S1009", getExceptionInterceptor());
    }

    --parameterIndex;

    if ((parameterIndex < 0) || (parameterIndex >= this.parameterBindings.length))
    {
      throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + this.parameterBindings.length, "S1009", getExceptionInterceptor());
    }

    if (this.parameterBindings[parameterIndex] == null) {
      this.parameterBindings[parameterIndex] = new BindValue();
    }
    else if ((this.parameterBindings[parameterIndex].isLongData) && (!(forLongData)))
    {
      this.detectedLongParameterSwitch = true;
    }

    this.parameterBindings[parameterIndex].isSet = true;
    this.parameterBindings[parameterIndex].boundBeforeExecutionNum = this.numberOfExecutions;

    return this.parameterBindings[parameterIndex];
  }

  byte[] getBytes(int parameterIndex)
    throws SQLException
  {
    BindValue bindValue = getBinding(parameterIndex, false);

    if (bindValue.isNull)
      return null;
    if (bindValue.isLongData)
      throw SQLError.notImplemented();

    if (this.outByteBuffer == null) {
      this.outByteBuffer = new Buffer(this.connection.getNetBufferLength());
    }

    this.outByteBuffer.clear();

    int originalPosition = this.outByteBuffer.getPosition();

    storeBinding(this.outByteBuffer, bindValue, this.connection.getIO());

    int newPosition = this.outByteBuffer.getPosition();

    int length = newPosition - originalPosition;

    byte[] valueAsBytes = new byte[length];

    System.arraycopy(this.outByteBuffer.getByteBuffer(), originalPosition, valueAsBytes, 0, length);

    return valueAsBytes;
  }

  public java.sql.ResultSetMetaData getMetaData()
    throws SQLException
  {
    checkClosed();

    if (this.resultFields == null) {
      return null;
    }

    return new ResultSetMetaData(this.resultFields, this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
  }

  public ParameterMetaData getParameterMetaData()
    throws SQLException
  {
    checkClosed();

    if (this.parameterMetaData == null) {
      this.parameterMetaData = new MysqlParameterMetadata(this.parameterFields, this.parameterCount, getExceptionInterceptor());
    }

    return this.parameterMetaData;
  }

  boolean isNull(int paramIndex)
  {
    throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
  }

  protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
    throws SQLException
  {
    if (this.isClosed) {
      return;
    }

    if (this.connection != null) {
      if (this.connection.getAutoGenerateTestcaseScript()) {
        dumpCloseForTestcase();
      }

      SQLException exceptionDuringClose = null;

      if ((calledExplicitly) && (!(this.connection.isClosed())))
        synchronized (this.connection.getMutex())
        {
          try {
            MysqlIO mysql = this.connection.getIO();

            Buffer packet = mysql.getSharedSendPacket();

            packet.writeByte(25);
            packet.writeLong(this.serverStatementId);

            mysql.sendCommand(25, null, packet, true, null, 0);
          }
          catch (SQLException sqlEx) {
            exceptionDuringClose = sqlEx;
          }
        }


      super.realClose(calledExplicitly, closeOpenResults);

      clearParametersInternal(false);
      this.parameterBindings = null;

      this.parameterFields = null;
      this.resultFields = null;

      if (exceptionDuringClose != null)
        throw exceptionDuringClose;
    }
  }

  protected void rePrepare()
    throws SQLException
  {
    this.invalidationException = null;
    try
    {
      serverPrepare(this.originalSql);
    }
    catch (SQLException sqlEx) {
      this.invalidationException = sqlEx;
    } catch (Exception ex) {
      this.invalidationException = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());

      this.invalidationException.initCause(ex);
    }

    if (this.invalidationException != null) {
      this.invalid = true;

      this.parameterBindings = null;

      this.parameterFields = null;
      this.resultFields = null;

      if (this.results != null)
        try {
          this.results.close();
        }
        catch (Exception ex)
        {
        }

      if (this.connection != null) {
        if (this.maxRowsChanged) {
          this.connection.unsetMaxRows(this);
        }

        if (!(this.connection.getDontTrackOpenResources()))
          this.connection.unregisterStatement(this);  }  }  } 
  // ERROR //
  private ResultSetInternalMethods serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, Field[] metadataFromCache) throws SQLException { // Byte code:
    //   0: aload_0
    //   1: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   4: invokevirtual 141	com/mysql/jdbc/ConnectionImpl:getMutex	()Ljava/lang/Object;
    //   7: dup
    //   8: astore 4
    //   10: monitorenter
    //   11: aload_0
    //   12: getfield 34	com/mysql/jdbc/ServerPreparedStatement:detectedLongParameterSwitch	Z
    //   15: ifeq +118 -> 133
    //   18: iconst_0
    //   19: istore 5
    //   21: lconst_0
    //   22: lstore 6
    //   24: iconst_0
    //   25: istore 8
    //   27: iload 8
    //   29: aload_0
    //   30: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   33: iconst_1
    //   34: isub
    //   35: if_icmpge +94 -> 129
    //   38: aload_0
    //   39: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   42: iload 8
    //   44: aaload
    //   45: getfield 111	com/mysql/jdbc/ServerPreparedStatement$BindValue:isLongData	Z
    //   48: ifeq +75 -> 123
    //   51: iload 5
    //   53: ifeq +55 -> 108
    //   56: lload 6
    //   58: aload_0
    //   59: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   62: iload 8
    //   64: aaload
    //   65: getfield 193	com/mysql/jdbc/ServerPreparedStatement$BindValue:boundBeforeExecutionNum	J
    //   68: lcmp
    //   69: ifeq +39 -> 108
    //   72: new 58	java/lang/StringBuffer
    //   75: dup
    //   76: invokespecial 59	java/lang/StringBuffer:<init>	()V
    //   79: ldc 227
    //   81: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   84: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   87: ldc 228
    //   89: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   92: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   95: invokevirtual 63	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   98: ldc 229
    //   100: aload_0
    //   101: invokevirtual 69	com/mysql/jdbc/ServerPreparedStatement:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
    //   104: invokestatic 70	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   107: athrow
    //   108: iconst_1
    //   109: istore 5
    //   111: aload_0
    //   112: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   115: iload 8
    //   117: aaload
    //   118: getfield 193	com/mysql/jdbc/ServerPreparedStatement$BindValue:boundBeforeExecutionNum	J
    //   121: lstore 6
    //   123: iinc 8 1
    //   126: goto -99 -> 27
    //   129: aload_0
    //   130: invokespecial 113	com/mysql/jdbc/ServerPreparedStatement:serverResetStatement	()V
    //   133: iconst_0
    //   134: istore 5
    //   136: iload 5
    //   138: aload_0
    //   139: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   142: if_icmpge +65 -> 207
    //   145: aload_0
    //   146: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   149: iload 5
    //   151: aaload
    //   152: getfield 192	com/mysql/jdbc/ServerPreparedStatement$BindValue:isSet	Z
    //   155: ifne +46 -> 201
    //   158: new 58	java/lang/StringBuffer
    //   161: dup
    //   162: invokespecial 59	java/lang/StringBuffer:<init>	()V
    //   165: ldc 230
    //   167: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   170: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   173: iload 5
    //   175: iconst_1
    //   176: iadd
    //   177: invokevirtual 119	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   180: ldc 231
    //   182: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   185: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   188: invokevirtual 63	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   191: ldc 140
    //   193: aload_0
    //   194: invokevirtual 69	com/mysql/jdbc/ServerPreparedStatement:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
    //   197: invokestatic 70	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   200: athrow
    //   201: iinc 5 1
    //   204: goto -68 -> 136
    //   207: iconst_0
    //   208: istore 5
    //   210: iload 5
    //   212: aload_0
    //   213: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   216: if_icmpge +35 -> 251
    //   219: aload_0
    //   220: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   223: iload 5
    //   225: aaload
    //   226: getfield 111	com/mysql/jdbc/ServerPreparedStatement$BindValue:isLongData	Z
    //   229: ifeq +16 -> 245
    //   232: aload_0
    //   233: iload 5
    //   235: aload_0
    //   236: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   239: iload 5
    //   241: aaload
    //   242: invokespecial 232	com/mysql/jdbc/ServerPreparedStatement:serverLongData	(ILcom/mysql/jdbc/ServerPreparedStatement$BindValue;)V
    //   245: iinc 5 1
    //   248: goto -38 -> 210
    //   251: aload_0
    //   252: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   255: invokevirtual 214	com/mysql/jdbc/ConnectionImpl:getAutoGenerateTestcaseScript	()Z
    //   258: ifeq +7 -> 265
    //   261: aload_0
    //   262: invokespecial 233	com/mysql/jdbc/ServerPreparedStatement:dumpExecuteForTestcase	()V
    //   265: aload_0
    //   266: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   269: invokevirtual 181	com/mysql/jdbc/ConnectionImpl:getIO	()Lcom/mysql/jdbc/MysqlIO;
    //   272: astore 5
    //   274: aload 5
    //   276: invokevirtual 217	com/mysql/jdbc/MysqlIO:getSharedSendPacket	()Lcom/mysql/jdbc/Buffer;
    //   279: astore 6
    //   281: aload 6
    //   283: invokevirtual 200	com/mysql/jdbc/Buffer:clear	()V
    //   286: aload 6
    //   288: bipush 23
    //   290: invokevirtual 7	com/mysql/jdbc/Buffer:writeByte	(B)V
    //   293: aload 6
    //   295: aload_0
    //   296: getfield 218	com/mysql/jdbc/ServerPreparedStatement:serverStatementId	J
    //   299: invokevirtual 8	com/mysql/jdbc/Buffer:writeLong	(J)V
    //   302: iconst_0
    //   303: istore 7
    //   305: aload_0
    //   306: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   309: iconst_4
    //   310: iconst_1
    //   311: iconst_2
    //   312: invokevirtual 49	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
    //   315: ifeq +71 -> 386
    //   318: aload_0
    //   319: getfield 204	com/mysql/jdbc/ServerPreparedStatement:resultFields	[Lcom/mysql/jdbc/Field;
    //   322: ifnull +52 -> 374
    //   325: aload_0
    //   326: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   329: invokevirtual 234	com/mysql/jdbc/ConnectionImpl:isCursorFetchEnabled	()Z
    //   332: ifeq +42 -> 374
    //   335: aload_0
    //   336: invokevirtual 235	com/mysql/jdbc/ServerPreparedStatement:getResultSetType	()I
    //   339: sipush 1003
    //   342: if_icmpne +32 -> 374
    //   345: aload_0
    //   346: invokevirtual 236	com/mysql/jdbc/ServerPreparedStatement:getResultSetConcurrency	()I
    //   349: sipush 1007
    //   352: if_icmpne +22 -> 374
    //   355: aload_0
    //   356: invokevirtual 237	com/mysql/jdbc/ServerPreparedStatement:getFetchSize	()I
    //   359: ifle +15 -> 374
    //   362: aload 6
    //   364: iconst_1
    //   365: invokevirtual 7	com/mysql/jdbc/Buffer:writeByte	(B)V
    //   368: iconst_1
    //   369: istore 7
    //   371: goto +9 -> 380
    //   374: aload 6
    //   376: iconst_0
    //   377: invokevirtual 7	com/mysql/jdbc/Buffer:writeByte	(B)V
    //   380: aload 6
    //   382: lconst_1
    //   383: invokevirtual 8	com/mysql/jdbc/Buffer:writeLong	(J)V
    //   386: aload_0
    //   387: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   390: bipush 7
    //   392: iadd
    //   393: bipush 8
    //   395: idiv
    //   396: istore 8
    //   398: aload 6
    //   400: invokevirtual 201	com/mysql/jdbc/Buffer:getPosition	()I
    //   403: istore 9
    //   405: iconst_0
    //   406: istore 10
    //   408: iload 10
    //   410: iload 8
    //   412: if_icmpge +15 -> 427
    //   415: aload 6
    //   417: iconst_0
    //   418: invokevirtual 7	com/mysql/jdbc/Buffer:writeByte	(B)V
    //   421: iinc 10 1
    //   424: goto -16 -> 408
    //   427: iload 8
    //   429: newarray byte
    //   431: astore 10
    //   433: aload 6
    //   435: aload_0
    //   436: getfield 36	com/mysql/jdbc/ServerPreparedStatement:sendTypesToServer	Z
    //   439: ifeq +7 -> 446
    //   442: iconst_1
    //   443: goto +4 -> 447
    //   446: iconst_0
    //   447: invokevirtual 7	com/mysql/jdbc/Buffer:writeByte	(B)V
    //   450: aload_0
    //   451: getfield 36	com/mysql/jdbc/ServerPreparedStatement:sendTypesToServer	Z
    //   454: ifeq +36 -> 490
    //   457: iconst_0
    //   458: istore 11
    //   460: iload 11
    //   462: aload_0
    //   463: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   466: if_icmpge +24 -> 490
    //   469: aload 6
    //   471: aload_0
    //   472: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   475: iload 11
    //   477: aaload
    //   478: getfield 91	com/mysql/jdbc/ServerPreparedStatement$BindValue:bufferType	I
    //   481: invokevirtual 238	com/mysql/jdbc/Buffer:writeInt	(I)V
    //   484: iinc 11 1
    //   487: goto -27 -> 460
    //   490: iconst_0
    //   491: istore 11
    //   493: iload 11
    //   495: aload_0
    //   496: getfield 74	com/mysql/jdbc/ServerPreparedStatement:parameterCount	I
    //   499: if_icmpge +72 -> 571
    //   502: aload_0
    //   503: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   506: iload 11
    //   508: aaload
    //   509: getfield 111	com/mysql/jdbc/ServerPreparedStatement$BindValue:isLongData	Z
    //   512: ifne +53 -> 565
    //   515: aload_0
    //   516: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   519: iload 11
    //   521: aaload
    //   522: getfield 89	com/mysql/jdbc/ServerPreparedStatement$BindValue:isNull	Z
    //   525: ifne +21 -> 546
    //   528: aload_0
    //   529: aload 6
    //   531: aload_0
    //   532: getfield 81	com/mysql/jdbc/ServerPreparedStatement:parameterBindings	[Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;
    //   535: iload 11
    //   537: aaload
    //   538: aload 5
    //   540: invokespecial 202	com/mysql/jdbc/ServerPreparedStatement:storeBinding	(Lcom/mysql/jdbc/Buffer;Lcom/mysql/jdbc/ServerPreparedStatement$BindValue;Lcom/mysql/jdbc/MysqlIO;)V
    //   543: goto +22 -> 565
    //   546: aload 10
    //   548: iload 11
    //   550: bipush 8
    //   552: idiv
    //   553: dup2
    //   554: baload
    //   555: iconst_1
    //   556: iload 11
    //   558: bipush 7
    //   560: iand
    //   561: ishl
    //   562: ior
    //   563: i2b
    //   564: bastore
    //   565: iinc 11 1
    //   568: goto -75 -> 493
    //   571: aload 6
    //   573: invokevirtual 201	com/mysql/jdbc/Buffer:getPosition	()I
    //   576: istore 11
    //   578: aload 6
    //   580: iload 9
    //   582: invokevirtual 239	com/mysql/jdbc/Buffer:setPosition	(I)V
    //   585: aload 6
    //   587: aload 10
    //   589: invokevirtual 240	com/mysql/jdbc/Buffer:writeBytesNoNull	([B)V
    //   592: aload 6
    //   594: iload 11
    //   596: invokevirtual 239	com/mysql/jdbc/Buffer:setPosition	(I)V
    //   599: lconst_0
    //   600: lstore 12
    //   602: aload_0
    //   603: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   606: invokevirtual 241	com/mysql/jdbc/ConnectionImpl:getLogSlowQueries	()Z
    //   609: istore 14
    //   611: aload_0
    //   612: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   615: invokevirtual 242	com/mysql/jdbc/ConnectionImpl:getGatherPerformanceMetrics	()Z
    //   618: istore 15
    //   620: aload_0
    //   621: getfield 243	com/mysql/jdbc/ServerPreparedStatement:profileSQL	Z
    //   624: ifne +13 -> 637
    //   627: iload 14
    //   629: ifne +8 -> 637
    //   632: iload 15
    //   634: ifeq +10 -> 644
    //   637: aload 5
    //   639: invokevirtual 244	com/mysql/jdbc/MysqlIO:getCurrentTimeNanosOrMillis	()J
    //   642: lstore 12
    //   644: aload_0
    //   645: invokevirtual 176	com/mysql/jdbc/ServerPreparedStatement:resetCancelledState	()V
    //   648: aconst_null
    //   649: astore 16
    //   651: aload_0
    //   652: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   655: invokevirtual 147	com/mysql/jdbc/ConnectionImpl:getEnableQueryTimeouts	()Z
    //   658: ifeq +52 -> 710
    //   661: aload_0
    //   662: getfield 245	com/mysql/jdbc/ServerPreparedStatement:timeoutInMillis	I
    //   665: ifeq +45 -> 710
    //   668: aload_0
    //   669: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   672: iconst_5
    //   673: iconst_0
    //   674: iconst_0
    //   675: invokevirtual 49	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
    //   678: ifeq +32 -> 710
    //   681: new 148	com/mysql/jdbc/StatementImpl$CancelTask
    //   684: dup
    //   685: aload_0
    //   686: aload_0
    //   687: invokespecial 149	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
    //   690: astore 16
    //   692: aload_0
    //   693: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   696: pop
    //   697: invokestatic 150	com/mysql/jdbc/ConnectionImpl:getCancelTimer	()Ljava/util/Timer;
    //   700: aload 16
    //   702: aload_0
    //   703: getfield 245	com/mysql/jdbc/ServerPreparedStatement:timeoutInMillis	I
    //   706: i2l
    //   707: invokevirtual 151	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
    //   710: aload 5
    //   712: bipush 23
    //   714: aconst_null
    //   715: aload 6
    //   717: iconst_0
    //   718: aconst_null
    //   719: iconst_0
    //   720: invokevirtual 219	com/mysql/jdbc/MysqlIO:sendCommand	(ILjava/lang/String;Lcom/mysql/jdbc/Buffer;ZLjava/lang/String;I)Lcom/mysql/jdbc/Buffer;
    //   723: astore 17
    //   725: lconst_0
    //   726: lstore 18
    //   728: iload 14
    //   730: ifne +15 -> 745
    //   733: iload 15
    //   735: ifne +10 -> 745
    //   738: aload_0
    //   739: getfield 243	com/mysql/jdbc/ServerPreparedStatement:profileSQL	Z
    //   742: ifeq +10 -> 752
    //   745: aload 5
    //   747: invokevirtual 244	com/mysql/jdbc/MysqlIO:getCurrentTimeNanosOrMillis	()J
    //   750: lstore 18
    //   752: aload 16
    //   754: ifnull +26 -> 780
    //   757: aload 16
    //   759: invokevirtual 175	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   762: pop
    //   763: aload 16
    //   765: getfield 246	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
    //   768: ifnull +9 -> 777
    //   771: aload 16
    //   773: getfield 246	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
    //   776: athrow
    //   777: aconst_null
    //   778: astore 16
    //   780: aload_0
    //   781: getfield 247	com/mysql/jdbc/ServerPreparedStatement:cancelTimeoutMutex	Ljava/lang/Object;
    //   784: dup
    //   785: astore 20
    //   787: monitorenter
    //   788: aload_0
    //   789: getfield 248	com/mysql/jdbc/ServerPreparedStatement:wasCancelled	Z
    //   792: ifeq +41 -> 833
    //   795: aconst_null
    //   796: astore 21
    //   798: aload_0
    //   799: getfield 249	com/mysql/jdbc/ServerPreparedStatement:wasCancelledByTimeout	Z
    //   802: ifeq +15 -> 817
    //   805: new 166	com/mysql/jdbc/exceptions/MySQLTimeoutException
    //   808: dup
    //   809: invokespecial 250	com/mysql/jdbc/exceptions/MySQLTimeoutException:<init>	()V
    //   812: astore 21
    //   814: goto +12 -> 826
    //   817: new 167	com/mysql/jdbc/exceptions/MySQLStatementCancelledException
    //   820: dup
    //   821: invokespecial 251	com/mysql/jdbc/exceptions/MySQLStatementCancelledException:<init>	()V
    //   824: astore 21
    //   826: aload_0
    //   827: invokevirtual 176	com/mysql/jdbc/ServerPreparedStatement:resetCancelledState	()V
    //   830: aload 21
    //   832: athrow
    //   833: aload 20
    //   835: monitorexit
    //   836: goto +11 -> 847
    //   839: astore 22
    //   841: aload 20
    //   843: monitorexit
    //   844: aload 22
    //   846: athrow
    //   847: iconst_0
    //   848: istore 20
    //   850: iload 14
    //   852: ifne +8 -> 860
    //   855: iload 15
    //   857: ifeq +257 -> 1114
    //   860: lload 18
    //   862: lload 12
    //   864: lsub
    //   865: lstore 21
    //   867: iload 14
    //   869: ifeq +54 -> 923
    //   872: aload_0
    //   873: getfield 52	com/mysql/jdbc/ServerPreparedStatement:useAutoSlowLog	Z
    //   876: ifeq +27 -> 903
    //   879: lload 21
    //   881: aload_0
    //   882: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   885: invokevirtual 252	com/mysql/jdbc/ConnectionImpl:getSlowQueryThresholdMillis	()I
    //   888: i2l
    //   889: lcmp
    //   890: ifle +7 -> 897
    //   893: iconst_1
    //   894: goto +4 -> 898
    //   897: iconst_0
    //   898: istore 20
    //   900: goto +23 -> 923
    //   903: aload_0
    //   904: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   907: lload 21
    //   909: invokevirtual 253	com/mysql/jdbc/ConnectionImpl:isAbonormallyLongQuery	(J)Z
    //   912: istore 20
    //   914: aload_0
    //   915: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   918: lload 21
    //   920: invokevirtual 254	com/mysql/jdbc/ConnectionImpl:reportQueryTime	(J)V
    //   923: iload 20
    //   925: ifeq +175 -> 1100
    //   928: new 58	java/lang/StringBuffer
    //   931: dup
    //   932: bipush 48
    //   934: aload_0
    //   935: getfield 64	com/mysql/jdbc/ServerPreparedStatement:originalSql	Ljava/lang/String;
    //   938: invokevirtual 131	java/lang/String:length	()I
    //   941: iadd
    //   942: invokespecial 132	java/lang/StringBuffer:<init>	(I)V
    //   945: astore 23
    //   947: aload 23
    //   949: ldc 255
    //   951: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   954: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   957: pop
    //   958: aload 23
    //   960: aload 5
    //   962: invokevirtual 256	com/mysql/jdbc/MysqlIO:getSlowQueryThreshold	()J
    //   965: invokevirtual 257	java/lang/StringBuffer:append	(J)Ljava/lang/StringBuffer;
    //   968: pop
    //   969: aload 23
    //   971: ldc_w 258
    //   974: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   977: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   980: pop
    //   981: aload 23
    //   983: lload 21
    //   985: invokevirtual 257	java/lang/StringBuffer:append	(J)Ljava/lang/StringBuffer;
    //   988: pop
    //   989: aload 23
    //   991: ldc_w 259
    //   994: invokestatic 138	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   997: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1000: pop
    //   1001: aload 23
    //   1003: ldc_w 260
    //   1006: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1009: pop
    //   1010: aload 23
    //   1012: aload_0
    //   1013: getfield 64	com/mysql/jdbc/ServerPreparedStatement:originalSql	Ljava/lang/String;
    //   1016: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1019: pop
    //   1020: aload 23
    //   1022: ldc_w 261
    //   1025: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1028: pop
    //   1029: aload 23
    //   1031: aload_0
    //   1032: iconst_1
    //   1033: invokevirtual 262	com/mysql/jdbc/ServerPreparedStatement:asSql	(Z)Ljava/lang/String;
    //   1036: invokevirtual 61	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1039: pop
    //   1040: aload_0
    //   1041: getfield 263	com/mysql/jdbc/ServerPreparedStatement:eventSink	Lcom/mysql/jdbc/profiler/ProfilerEventHandler;
    //   1044: new 264	com/mysql/jdbc/profiler/ProfilerEvent
    //   1047: dup
    //   1048: bipush 6
    //   1050: ldc_w 265
    //   1053: aload_0
    //   1054: getfield 86	com/mysql/jdbc/ServerPreparedStatement:currentCatalog	Ljava/lang/String;
    //   1057: aload_0
    //   1058: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1061: invokevirtual 266	com/mysql/jdbc/ConnectionImpl:getId	()J
    //   1064: aload_0
    //   1065: invokevirtual 267	com/mysql/jdbc/ServerPreparedStatement:getId	()I
    //   1068: iconst_0
    //   1069: invokestatic 268	java/lang/System:currentTimeMillis	()J
    //   1072: lload 21
    //   1074: aload 5
    //   1076: invokevirtual 269	com/mysql/jdbc/MysqlIO:getQueryTimingUnits	()Ljava/lang/String;
    //   1079: aconst_null
    //   1080: new 270	java/lang/Throwable
    //   1083: dup
    //   1084: invokespecial 271	java/lang/Throwable:<init>	()V
    //   1087: aload 23
    //   1089: invokevirtual 63	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   1092: invokespecial 272	com/mysql/jdbc/profiler/ProfilerEvent:<init>	(BLjava/lang/String;Ljava/lang/String;JIIJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   1095: invokeinterface 273 2 0
    //   1100: iload 15
    //   1102: ifeq +12 -> 1114
    //   1105: aload_0
    //   1106: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1109: lload 21
    //   1111: invokevirtual 274	com/mysql/jdbc/ConnectionImpl:registerQueryExecutionTime	(J)V
    //   1114: aload_0
    //   1115: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1118: invokevirtual 275	com/mysql/jdbc/ConnectionImpl:incrementNumberOfPreparedExecutes	()V
    //   1121: aload_0
    //   1122: getfield 243	com/mysql/jdbc/ServerPreparedStatement:profileSQL	Z
    //   1125: ifeq +82 -> 1207
    //   1128: aload_0
    //   1129: aload_0
    //   1130: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1133: invokestatic 276	com/mysql/jdbc/profiler/ProfilerEventHandlerFactory:getInstance	(Lcom/mysql/jdbc/ConnectionImpl;)Lcom/mysql/jdbc/profiler/ProfilerEventHandler;
    //   1136: putfield 263	com/mysql/jdbc/ServerPreparedStatement:eventSink	Lcom/mysql/jdbc/profiler/ProfilerEventHandler;
    //   1139: aload_0
    //   1140: getfield 263	com/mysql/jdbc/ServerPreparedStatement:eventSink	Lcom/mysql/jdbc/profiler/ProfilerEventHandler;
    //   1143: new 264	com/mysql/jdbc/profiler/ProfilerEvent
    //   1146: dup
    //   1147: iconst_4
    //   1148: ldc_w 265
    //   1151: aload_0
    //   1152: getfield 86	com/mysql/jdbc/ServerPreparedStatement:currentCatalog	Ljava/lang/String;
    //   1155: aload_0
    //   1156: getfield 277	com/mysql/jdbc/ServerPreparedStatement:connectionId	J
    //   1159: aload_0
    //   1160: getfield 118	com/mysql/jdbc/ServerPreparedStatement:statementId	I
    //   1163: iconst_m1
    //   1164: invokestatic 268	java/lang/System:currentTimeMillis	()J
    //   1167: aload 5
    //   1169: invokevirtual 244	com/mysql/jdbc/MysqlIO:getCurrentTimeNanosOrMillis	()J
    //   1172: lload 12
    //   1174: lsub
    //   1175: l2i
    //   1176: i2l
    //   1177: aload 5
    //   1179: invokevirtual 269	com/mysql/jdbc/MysqlIO:getQueryTimingUnits	()Ljava/lang/String;
    //   1182: aconst_null
    //   1183: new 270	java/lang/Throwable
    //   1186: dup
    //   1187: invokespecial 271	java/lang/Throwable:<init>	()V
    //   1190: aload_0
    //   1191: aload_0
    //   1192: iconst_1
    //   1193: invokevirtual 262	com/mysql/jdbc/ServerPreparedStatement:asSql	(Z)Ljava/lang/String;
    //   1196: invokespecial 278	com/mysql/jdbc/ServerPreparedStatement:truncateQueryToLog	(Ljava/lang/String;)Ljava/lang/String;
    //   1199: invokespecial 272	com/mysql/jdbc/profiler/ProfilerEvent:<init>	(BLjava/lang/String;Ljava/lang/String;JIIJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   1202: invokeinterface 273 2 0
    //   1207: aload 5
    //   1209: aload_0
    //   1210: iload_1
    //   1211: aload_0
    //   1212: getfield 279	com/mysql/jdbc/ServerPreparedStatement:resultSetType	I
    //   1215: aload_0
    //   1216: getfield 280	com/mysql/jdbc/ServerPreparedStatement:resultSetConcurrency	I
    //   1219: iload_2
    //   1220: aload_0
    //   1221: getfield 86	com/mysql/jdbc/ServerPreparedStatement:currentCatalog	Ljava/lang/String;
    //   1224: aload 17
    //   1226: iconst_1
    //   1227: aload_0
    //   1228: getfield 281	com/mysql/jdbc/ServerPreparedStatement:fieldCount	I
    //   1231: i2l
    //   1232: aload_3
    //   1233: invokevirtual 282	com/mysql/jdbc/MysqlIO:readAllResults	(Lcom/mysql/jdbc/StatementImpl;IIIZLjava/lang/String;Lcom/mysql/jdbc/Buffer;ZJ[Lcom/mysql/jdbc/Field;)Lcom/mysql/jdbc/ResultSetImpl;
    //   1236: astore 21
    //   1238: aload_0
    //   1239: getfield 243	com/mysql/jdbc/ServerPreparedStatement:profileSQL	Z
    //   1242: ifeq +68 -> 1310
    //   1245: aload 5
    //   1247: invokevirtual 244	com/mysql/jdbc/MysqlIO:getCurrentTimeNanosOrMillis	()J
    //   1250: lstore 22
    //   1252: aload_0
    //   1253: getfield 263	com/mysql/jdbc/ServerPreparedStatement:eventSink	Lcom/mysql/jdbc/profiler/ProfilerEventHandler;
    //   1256: new 264	com/mysql/jdbc/profiler/ProfilerEvent
    //   1259: dup
    //   1260: iconst_5
    //   1261: ldc_w 265
    //   1264: aload_0
    //   1265: getfield 86	com/mysql/jdbc/ServerPreparedStatement:currentCatalog	Ljava/lang/String;
    //   1268: aload_0
    //   1269: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1272: invokevirtual 266	com/mysql/jdbc/ConnectionImpl:getId	()J
    //   1275: aload_0
    //   1276: invokevirtual 267	com/mysql/jdbc/ServerPreparedStatement:getId	()I
    //   1279: iconst_0
    //   1280: invokestatic 268	java/lang/System:currentTimeMillis	()J
    //   1283: lload 22
    //   1285: lload 18
    //   1287: lsub
    //   1288: aload 5
    //   1290: invokevirtual 269	com/mysql/jdbc/MysqlIO:getQueryTimingUnits	()Ljava/lang/String;
    //   1293: aconst_null
    //   1294: new 270	java/lang/Throwable
    //   1297: dup
    //   1298: invokespecial 271	java/lang/Throwable:<init>	()V
    //   1301: aconst_null
    //   1302: invokespecial 272	com/mysql/jdbc/profiler/ProfilerEvent:<init>	(BLjava/lang/String;Ljava/lang/String;JIIJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   1305: invokeinterface 273 2 0
    //   1310: iload 20
    //   1312: ifeq +32 -> 1344
    //   1315: aload_0
    //   1316: getfield 48	com/mysql/jdbc/ServerPreparedStatement:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   1319: invokevirtual 283	com/mysql/jdbc/ConnectionImpl:getExplainSlowQueries	()Z
    //   1322: ifeq +22 -> 1344
    //   1325: aload_0
    //   1326: iconst_1
    //   1327: invokevirtual 262	com/mysql/jdbc/ServerPreparedStatement:asSql	(Z)Ljava/lang/String;
    //   1330: astore 22
    //   1332: aload 5
    //   1334: aload 22
    //   1336: invokevirtual 284	java/lang/String:getBytes	()[B
    //   1339: aload 22
    //   1341: invokevirtual 285	com/mysql/jdbc/MysqlIO:explainSlowQuery	([BLjava/lang/String;)V
    //   1344: iload_2
    //   1345: ifne +14 -> 1359
    //   1348: aload_0
    //   1349: getfield 50	com/mysql/jdbc/ServerPreparedStatement:serverNeedsResetBeforeEachExecution	Z
    //   1352: ifeq +7 -> 1359
    //   1355: aload_0
    //   1356: invokespecial 113	com/mysql/jdbc/ServerPreparedStatement:serverResetStatement	()V
    //   1359: aload_0
    //   1360: iconst_0
    //   1361: putfield 36	com/mysql/jdbc/ServerPreparedStatement:sendTypesToServer	Z
    //   1364: aload_0
    //   1365: aload 21
    //   1367: putfield 221	com/mysql/jdbc/ServerPreparedStatement:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
    //   1370: aload 5
    //   1372: invokevirtual 286	com/mysql/jdbc/MysqlIO:hadWarnings	()Z
    //   1375: ifeq +8 -> 1383
    //   1378: aload 5
    //   1380: invokevirtual 287	com/mysql/jdbc/MysqlIO:scanForAndThrowDataTruncation	()V
    //   1383: aload 21
    //   1385: astore 22
    //   1387: aload 16
    //   1389: ifnull +9 -> 1398
    //   1392: aload 16
    //   1394: invokevirtual 175	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   1397: pop
    //   1398: aload 4
    //   1400: monitorexit
    //   1401: aload 22
    //   1403: areturn
    //   1404: astore 24
    //   1406: aload 16
    //   1408: ifnull +9 -> 1417
    //   1411: aload 16
    //   1413: invokevirtual 175	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
    //   1416: pop
    //   1417: aload 24
    //   1419: athrow
    //   1420: astore 25
    //   1422: aload 4
    //   1424: monitorexit
    //   1425: aload 25
    //   1427: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   788	836	839	finally
    //   839	844	839	finally
    //   651	1387	1404	finally
    //   1404	1406	1404	finally
    //   11	1401	1420	finally
    //   1404	1425	1420	finally } 
  private void serverLongData(int parameterIndex, BindValue longData) throws SQLException { synchronized (this.connection.getMutex()) {
      MysqlIO mysql = this.connection.getIO();

      Buffer packet = mysql.getSharedSendPacket();

      Object value = longData.value;

      if (value instanceof byte[]) {
        packet.clear();
        packet.writeByte(24);
        packet.writeLong(this.serverStatementId);
        packet.writeInt(parameterIndex);

        packet.writeBytesNoNull((byte[])longData.value);

        mysql.sendCommand(24, null, packet, true, null, 0);
      }
      else if (value instanceof InputStream) {
        storeStream(mysql, parameterIndex, packet, (InputStream)value);
      } else if (value instanceof Blob) {
        storeStream(mysql, parameterIndex, packet, ((Blob)value).getBinaryStream());
      }
      else if (value instanceof Reader) {
        storeReader(mysql, parameterIndex, packet, (Reader)value);
      } else {
        throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.18") + value.getClass().getName() + "'", "S1009", getExceptionInterceptor());
      }
    }
  }

  private void serverPrepare(String sql)
    throws SQLException
  {
    synchronized (this.connection.getMutex()) {
      MysqlIO mysql = this.connection.getIO();

      if (this.connection.getAutoGenerateTestcaseScript())
        dumpPrepareForTestcase();

      try
      {
        int i;
        long begin = 0L;

        if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA"))
          this.isLoadDataQuery = true;
        else {
          this.isLoadDataQuery = false;
        }

        if (this.connection.getProfileSql()) {
          begin = System.currentTimeMillis();
        }

        String characterEncoding = null;
        String connectionEncoding = this.connection.getEncoding();

        if ((!(this.isLoadDataQuery)) && (this.connection.getUseUnicode()) && (connectionEncoding != null))
        {
          characterEncoding = connectionEncoding;
        }

        Buffer prepareResultPacket = mysql.sendCommand(22, sql, null, false, characterEncoding, 0);

        if (this.connection.versionMeetsMinimum(4, 1, 1))
        {
          prepareResultPacket.setPosition(1);
        }
        else
        {
          prepareResultPacket.setPosition(0);
        }

        this.serverStatementId = prepareResultPacket.readLong();
        this.fieldCount = prepareResultPacket.readInt();
        this.parameterCount = prepareResultPacket.readInt();
        this.parameterBindings = new BindValue[this.parameterCount];

        for (int i = 0; i < this.parameterCount; ++i) {
          this.parameterBindings[i] = new BindValue();
        }

        this.connection.incrementNumberOfPrepares();

        if (this.profileSQL) {
          this.eventSink.consumeEvent(new ProfilerEvent(2, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), mysql.getCurrentTimeNanosOrMillis() - begin, mysql.getQueryTimingUnits(), null, new Throwable(), truncateQueryToLog(sql)));
        }

        if ((this.parameterCount > 0) && 
          (this.connection.versionMeetsMinimum(4, 1, 2)) && (!(mysql.isVersion(5, 0, 0))))
        {
          this.parameterFields = new Field[this.parameterCount];

          Buffer metaDataPacket = mysql.readPacket();

          i = 0;

          while ((!(metaDataPacket.isLastDataPacket())) && (i < this.parameterCount)) {
            this.parameterFields[(i++)] = mysql.unpackField(metaDataPacket, false);

            metaDataPacket = mysql.readPacket();
          }

        }

        if (this.fieldCount > 0) {
          this.resultFields = new Field[this.fieldCount];

          Buffer fieldPacket = mysql.readPacket();

          i = 0;

          while ((!(fieldPacket.isLastDataPacket())) && (i < this.fieldCount)) {
            this.resultFields[(i++)] = mysql.unpackField(fieldPacket, false);

            fieldPacket = mysql.readPacket();
          }
        }
      } catch (SQLException sqlEx) {
        StringBuffer messageBuf;
        if (this.connection.getDumpQueriesOnException()) {
          messageBuf = new StringBuffer(this.originalSql.length() + 32);

          messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");

          messageBuf.append(this.originalSql);
        }

        throw sqlEx;
      }
      finally
      {
        this.connection.getIO().clearInputStream();
      }
    }
  }

  private String truncateQueryToLog(String sql) {
    String query = null;

    if (sql.length() > this.connection.getMaxQuerySizeToLog()) {
      StringBuffer queryBuf = new StringBuffer(this.connection.getMaxQuerySizeToLog() + 12);

      queryBuf.append(sql.substring(0, this.connection.getMaxQuerySizeToLog()));
      queryBuf.append(Messages.getString("MysqlIO.25"));

      query = queryBuf.toString();
    } else {
      query = sql;
    }

    return query;
  }

  private void serverResetStatement() throws SQLException {
    synchronized (this.connection.getMutex())
    {
      MysqlIO mysql = this.connection.getIO();

      Buffer packet = mysql.getSharedSendPacket();

      packet.clear();
      packet.writeByte(26);
      packet.writeLong(this.serverStatementId);
      try
      {
        mysql.sendCommand(26, null, packet, !(this.connection.versionMeetsMinimum(4, 1, 2)), null, 0);
      }
      catch (SQLException sqlEx) {
      }
      catch (Exception ex) {
        SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());

        throw sqlEx;
      } finally {
        mysql.clearInputStream();
      }
    }
  }

  public void setArray(int i, Array x)
    throws SQLException
  {
    throw SQLError.notImplemented();
  }

  public void setAsciiStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, true);
      setType(binding, 252);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = true;

      if (this.connection.getUseStreamLengthsInPrepStmts())
        binding.bindLength = length;
      else
        binding.bindLength = -1L;
    }
  }

  public void setBigDecimal(int parameterIndex, BigDecimal x)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, 3);
    }
    else {
      BindValue binding = getBinding(parameterIndex, false);

      if (this.connection.versionMeetsMinimum(5, 0, 3))
        setType(binding, 246);
      else {
        setType(binding, this.stringTypeCode);
      }

      binding.value = StringUtils.fixDecimalExponent(StringUtils.consistentToString(x));

      binding.isNull = false;
      binding.isLongData = false;
    }
  }

  public void setBinaryStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, true);
      setType(binding, 252);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = true;

      if (this.connection.getUseStreamLengthsInPrepStmts())
        binding.bindLength = length;
      else
        binding.bindLength = -1L;
    }
  }

  public void setBlob(int parameterIndex, Blob x)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, true);
      setType(binding, 252);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = true;

      if (this.connection.getUseStreamLengthsInPrepStmts())
        binding.bindLength = x.length();
      else
        binding.bindLength = -1L;
    }
  }

  public void setBoolean(int parameterIndex, boolean x)
    throws SQLException
  {
    setByte(parameterIndex, (x) ? 1 : 0);
  }

  public void setByte(int parameterIndex, byte x)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 1);

    binding.value = null;
    binding.byteBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setBytes(int parameterIndex, byte[] x)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, false);
      setType(binding, 253);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = false;
    }
  }

  public void setCharacterStream(int parameterIndex, Reader reader, int length)
    throws SQLException
  {
    checkClosed();

    if (reader == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, true);
      setType(binding, 252);

      binding.value = reader;
      binding.isNull = false;
      binding.isLongData = true;

      if (this.connection.getUseStreamLengthsInPrepStmts())
        binding.bindLength = length;
      else
        binding.bindLength = -1L;
    }
  }

  public void setClob(int parameterIndex, Clob x)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, -2);
    } else {
      BindValue binding = getBinding(parameterIndex, true);
      setType(binding, 252);

      binding.value = x.getCharacterStream();
      binding.isNull = false;
      binding.isLongData = true;

      if (this.connection.getUseStreamLengthsInPrepStmts())
        binding.bindLength = x.length();
      else
        binding.bindLength = -1L;
    }
  }

  public void setDate(int parameterIndex, java.sql.Date x)
    throws SQLException
  {
    setDate(parameterIndex, x, null);
  }

  public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
    throws SQLException
  {
    if (x == null) {
      setNull(parameterIndex, 91);
    } else {
      BindValue binding = getBinding(parameterIndex, false);
      setType(binding, 10);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = false;
    }
  }

  public void setDouble(int parameterIndex, double x)
    throws SQLException
  {
    checkClosed();

    if ((!(this.connection.getAllowNanAndInf())) && (((x == (1.0D / 0.0D)) || (x == (-1.0D / 0.0D)) || (Double.isNaN(x)))))
    {
      throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
    }

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 5);

    binding.value = null;
    binding.doubleBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setFloat(int parameterIndex, float x)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 4);

    binding.value = null;
    binding.floatBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setInt(int parameterIndex, int x)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 3);

    binding.value = null;
    binding.intBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setLong(int parameterIndex, long x)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 8);

    binding.value = null;
    binding.longBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setNull(int parameterIndex, int sqlType)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);

    if (binding.bufferType == 0) {
      setType(binding, 6);
    }

    binding.value = null;
    binding.isNull = true;
    binding.isLongData = false;
  }

  public void setNull(int parameterIndex, int sqlType, String typeName)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);

    if (binding.bufferType == 0) {
      setType(binding, 6);
    }

    binding.value = null;
    binding.isNull = true;
    binding.isLongData = false;
  }

  public void setRef(int i, Ref x)
    throws SQLException
  {
    throw SQLError.notImplemented();
  }

  public void setShort(int parameterIndex, short x)
    throws SQLException
  {
    checkClosed();

    BindValue binding = getBinding(parameterIndex, false);
    setType(binding, 2);

    binding.value = null;
    binding.shortBinding = x;
    binding.isNull = false;
    binding.isLongData = false;
  }

  public void setString(int parameterIndex, String x)
    throws SQLException
  {
    checkClosed();

    if (x == null) {
      setNull(parameterIndex, 1);
    } else {
      BindValue binding = getBinding(parameterIndex, false);

      setType(binding, this.stringTypeCode);

      binding.value = x;
      binding.isNull = false;
      binding.isLongData = false;
    }
  }

  public void setTime(int parameterIndex, Time x)
    throws SQLException
  {
    setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
  }

  public void setTime(int parameterIndex, Time x, Calendar cal)
    throws SQLException
  {
    setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
  }

  public void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
    throws SQLException
  {
    if (x == null) {
      setNull(parameterIndex, 92);
    } else {
      BindValue binding = getBinding(parameterIndex, false);
      setType(binding, 11);

      if (!(this.useLegacyDatetimeCode)) {
        binding.value = x;
      } else {
        Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();

        synchronized (sessionCalendar) {
          binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
        }

      }

      binding.isNull = false;
      binding.isLongData = false;
    }
  }

  public void setTimestamp(int parameterIndex, Timestamp x)
    throws SQLException
  {
    setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
  }

  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
    throws SQLException
  {
    setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
  }

  protected void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
    throws SQLException
  {
    if (x == null) {
      setNull(parameterIndex, 93);
    } else {
      BindValue binding = getBinding(parameterIndex, false);
      setType(binding, 12);

      if (!(this.useLegacyDatetimeCode)) {
        binding.value = x;
      } else {
        Calendar sessionCalendar = (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();

        synchronized (sessionCalendar) {
          binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
        }

        binding.isNull = false;
        binding.isLongData = false;
      }
    }
  }

  protected void setType(BindValue oldValue, int bufferType) {
    if (oldValue.bufferType != bufferType) {
      this.sendTypesToServer = true;
    }

    oldValue.bufferType = bufferType;
  }

  /**
   * @deprecated
   */
  public void setUnicodeStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    checkClosed();

    throw SQLError.notImplemented();
  }

  public void setURL(int parameterIndex, URL x)
    throws SQLException
  {
    checkClosed();

    setString(parameterIndex, x.toString());
  }

  private void storeBinding(Buffer packet, BindValue bindValue, MysqlIO mysql)
    throws SQLException
  {
    Object value;
    try
    {
      value = bindValue.value;

      switch (bindValue.bufferType)
      {
      case 1:
        packet.writeByte(bindValue.byteBinding);
        return;
      case 2:
        packet.ensureCapacity(2);
        packet.writeInt(bindValue.shortBinding);
        return;
      case 3:
        packet.ensureCapacity(4);
        packet.writeLong(bindValue.intBinding);
        return;
      case 8:
        packet.ensureCapacity(8);
        packet.writeLongLong(bindValue.longBinding);
        return;
      case 4:
        packet.ensureCapacity(4);
        packet.writeFloat(bindValue.floatBinding);
        return;
      case 5:
        packet.ensureCapacity(8);
        packet.writeDouble(bindValue.doubleBinding);
        return;
      case 11:
        storeTime(packet, (Time)value);
        return;
      case 7:
      case 10:
      case 12:
        storeDateTime(packet, (Date)value, mysql, bindValue.bufferType);
        return;
      case 0:
      case 15:
      case 246:
      case 253:
      case 254:
        if (value instanceof byte[])
          packet.writeLenBytes((byte[])value);
        else if (!(this.isLoadDataQuery)) {
          packet.writeLenString((String)value, this.charEncoding, this.connection.getServerCharacterEncoding(), this.charConverter, this.connection.parserKnowsUnicode(), this.connection);
        }
        else
        {
          packet.writeLenBytes(((String)value).getBytes());
        }

        return;
      }
    }
    catch (UnsupportedEncodingException uEE)
    {
      throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.22") + this.connection.getEncoding() + "'", "S1000", getExceptionInterceptor());
    }
  }

  private void storeDateTime412AndOlder(Buffer intoBuf, Date dt, int bufferType)
    throws SQLException
  {
    Calendar sessionCalendar = null;

    if (!(this.useLegacyDatetimeCode))
      if (bufferType == 10)
        sessionCalendar = getDefaultTzCalendar();
      else
        sessionCalendar = getServerTzCalendar();

    else {
      sessionCalendar = ((dt instanceof Timestamp) && (this.connection.getUseJDBCCompliantTimezoneShift())) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
    }

    synchronized (sessionCalendar) {
      Date oldTime = sessionCalendar.getTime();
      try
      {
        intoBuf.ensureCapacity(8);
        intoBuf.writeByte(7);

        sessionCalendar.setTime(dt);

        int year = sessionCalendar.get(1);
        int month = sessionCalendar.get(2) + 1;
        int date = sessionCalendar.get(5);

        intoBuf.writeInt(year);
        intoBuf.writeByte((byte)month);
        intoBuf.writeByte((byte)date);

        if (dt instanceof java.sql.Date) {
          intoBuf.writeByte(0);
          intoBuf.writeByte(0);
          intoBuf.writeByte(0);
        } else {
          intoBuf.writeByte((byte)sessionCalendar.get(11));

          intoBuf.writeByte((byte)sessionCalendar.get(12));

          intoBuf.writeByte((byte)sessionCalendar.get(13));
        }
      }
      finally {
        sessionCalendar.setTime(oldTime);
      }
    }
  }

  private void storeDateTime(Buffer intoBuf, Date dt, MysqlIO mysql, int bufferType) throws SQLException
  {
    if (this.connection.versionMeetsMinimum(4, 1, 3))
      storeDateTime413AndNewer(intoBuf, dt, bufferType);
    else
      storeDateTime412AndOlder(intoBuf, dt, bufferType);
  }

  private void storeDateTime413AndNewer(Buffer intoBuf, Date dt, int bufferType)
    throws SQLException
  {
    Calendar sessionCalendar = null;

    if (!(this.useLegacyDatetimeCode))
      if (bufferType == 10)
        sessionCalendar = getDefaultTzCalendar();
      else
        sessionCalendar = getServerTzCalendar();

    else {
      sessionCalendar = ((dt instanceof Timestamp) && (this.connection.getUseJDBCCompliantTimezoneShift())) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
    }

    synchronized (sessionCalendar) {
      Date oldTime = sessionCalendar.getTime();
      try
      {
        sessionCalendar.setTime(dt);

        if (dt instanceof java.sql.Date) {
          sessionCalendar.set(11, 0);
          sessionCalendar.set(12, 0);
          sessionCalendar.set(13, 0);
        }

        byte length = 7;

        if (dt instanceof Timestamp) {
          length = 11;
        }

        intoBuf.ensureCapacity(length);

        intoBuf.writeByte(length);

        int year = sessionCalendar.get(1);
        int month = sessionCalendar.get(2) + 1;
        int date = sessionCalendar.get(5);

        intoBuf.writeInt(year);
        intoBuf.writeByte((byte)month);
        intoBuf.writeByte((byte)date);

        if (dt instanceof java.sql.Date) {
          intoBuf.writeByte(0);
          intoBuf.writeByte(0);
          intoBuf.writeByte(0);
        } else {
          intoBuf.writeByte((byte)sessionCalendar.get(11));

          intoBuf.writeByte((byte)sessionCalendar.get(12));

          intoBuf.writeByte((byte)sessionCalendar.get(13));
        }

        if (length == 11)
        {
          intoBuf.writeLong(((Timestamp)dt).getNanos() / 1000);
        }
      }
      finally {
        sessionCalendar.setTime(oldTime);
      }
    }
  }

  private Calendar getServerTzCalendar() {
    synchronized (this) {
      if (this.serverTzCalendar == null) {
        this.serverTzCalendar = new GregorianCalendar(this.connection.getServerTimezoneTZ());
      }

      return this.serverTzCalendar;
    }
  }

  private Calendar getDefaultTzCalendar() {
    synchronized (this) {
      if (this.defaultTzCalendar == null) {
        this.defaultTzCalendar = new GregorianCalendar(TimeZone.getDefault());
      }

      return this.defaultTzCalendar;
    }
  }

  private void storeReader(MysqlIO mysql, int parameterIndex, Buffer packet, Reader inStream)
    throws SQLException
  {
    String forcedEncoding = this.connection.getClobCharacterEncoding();

    String clobEncoding = (forcedEncoding == null) ? this.connection.getEncoding() : forcedEncoding;

    int maxBytesChar = 2;

    if (clobEncoding != null)
      if (!(clobEncoding.equals("UTF-16"))) {
        maxBytesChar = this.connection.getMaxBytesPerChar(clobEncoding);

        if (maxBytesChar == 1)
          maxBytesChar = 2;
      }
      else {
        maxBytesChar = 4;
      }


    char[] buf = new char[8192 / maxBytesChar];

    int numRead = 0;

    int bytesInPacket = 0;
    int totalBytesRead = 0;
    int bytesReadAtLastSend = 0;
    int packetIsFullAt = this.connection.getBlobSendChunkSize();
    try
    {
      packet.clear();
      packet.writeByte(24);
      packet.writeLong(this.serverStatementId);
      packet.writeInt(parameterIndex);

      boolean readAny = false;

      while ((numRead = inStream.read(buf)) != -1) {
        readAny = true;

        byte[] valueAsBytes = StringUtils.getBytes(buf, null, clobEncoding, this.connection.getServerCharacterEncoding(), 0, numRead, this.connection.parserKnowsUnicode(), getExceptionInterceptor());

        packet.writeBytesNoNull(valueAsBytes, 0, valueAsBytes.length);

        bytesInPacket += valueAsBytes.length;
        totalBytesRead += valueAsBytes.length;

        if (bytesInPacket >= packetIsFullAt) {
          bytesReadAtLastSend = totalBytesRead;

          mysql.sendCommand(24, null, packet, true, null, 0);

          bytesInPacket = 0;
          packet.clear();
          packet.writeByte(24);
          packet.writeLong(this.serverStatementId);
          packet.writeInt(parameterIndex);
        }
      }

      if (totalBytesRead != bytesReadAtLastSend) {
        mysql.sendCommand(24, null, packet, true, null, 0);
      }

      if (!(readAny))
        mysql.sendCommand(24, null, packet, true, null, 0);
    }
    catch (IOException ioEx)
    {
      SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.24") + ioEx.toString(), "S1000", getExceptionInterceptor());

      throw sqlEx;
    } finally {
      if ((this.connection.getAutoClosePStmtStreams()) && 
        (inStream != null))
        try {
          inStream.close();
        }
        catch (IOException ioEx)
        {
        }
    }
  }

  private void storeStream(MysqlIO mysql, int parameterIndex, Buffer packet, InputStream inStream)
    throws SQLException
  {
    byte[] buf = new byte[8192];

    int numRead = 0;
    try
    {
      int bytesInPacket = 0;
      int totalBytesRead = 0;
      int bytesReadAtLastSend = 0;
      int packetIsFullAt = this.connection.getBlobSendChunkSize();

      packet.clear();
      packet.writeByte(24);
      packet.writeLong(this.serverStatementId);
      packet.writeInt(parameterIndex);

      boolean readAny = false;
      while (true) {
        do { if ((numRead = inStream.read(buf)) == -1)
            break label146;
          readAny = true;

          packet.writeBytesNoNull(buf, 0, numRead);
          bytesInPacket += numRead;
          totalBytesRead += numRead;
        }
        while (bytesInPacket < packetIsFullAt);
        bytesReadAtLastSend = totalBytesRead;

        mysql.sendCommand(24, null, packet, true, null, 0);

        bytesInPacket = 0;
        packet.clear();
        packet.writeByte(24);
        packet.writeLong(this.serverStatementId);
        packet.writeInt(parameterIndex);
      }

      if (totalBytesRead != bytesReadAtLastSend) {
        label146: mysql.sendCommand(24, null, packet, true, null, 0);
      }

      if (!(readAny))
        mysql.sendCommand(24, null, packet, true, null, 0);
    }
    catch (IOException ioEx)
    {
      SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.25") + ioEx.toString(), "S1000", getExceptionInterceptor());

      throw sqlEx;
    } finally {
      if ((this.connection.getAutoClosePStmtStreams()) && 
        (inStream != null))
        try {
          inStream.close();
        }
        catch (IOException ioEx)
        {
        }
    }
  }

  public String toString()
  {
    StringBuffer toStringBuf = new StringBuffer();

    toStringBuf.append("com.mysql.jdbc.ServerPreparedStatement[");
    toStringBuf.append(this.serverStatementId);
    toStringBuf.append("] - ");
    try
    {
      toStringBuf.append(asSql());
    } catch (SQLException sqlEx) {
      toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
      toStringBuf.append(sqlEx);
    }

    return toStringBuf.toString();
  }

  protected long getServerStatementId() {
    return this.serverStatementId;
  }

  public synchronized boolean canRewriteAsMultiValueInsertAtSqlLevel()
    throws SQLException
  {
    if (!(this.hasCheckedRewrite)) {
      this.hasCheckedRewrite = true;
      this.canRewrite = canRewrite(this.originalSql, isOnDuplicateKeyUpdate(), getLocationOfOnDuplicateKeyUpdate(), 0);

      this.parseInfo = new PreparedStatement.ParseInfo(this, this.originalSql, this.connection, this.connection.getMetaData(), this.charEncoding, this.charConverter);
    }

    return this.canRewrite;
  }

  public synchronized boolean canRewriteAsMultivalueInsertStatement() throws SQLException
  {
    if (!(canRewriteAsMultiValueInsertAtSqlLevel())) {
      return false;
    }

    BindValue[] currentBindValues = null;
    BindValue[] previousBindValues = null;

    int nbrCommands = this.batchedArgs.size();

    for (int commandIndex = 0; commandIndex < nbrCommands; ++commandIndex) {
      int j;
      Object arg = this.batchedArgs.get(commandIndex);

      if (!(arg instanceof String))
      {
        currentBindValues = ((BatchedBindValues)arg).batchedParameterValues;

        if (previousBindValues != null) {
          for (j = 0; j < this.parameterBindings.length; ++j)
            if (currentBindValues[j].bufferType != previousBindValues[j].bufferType)
              return false;


        }

      }

    }

    return true;
  }

  protected synchronized int getLocationOfOnDuplicateKeyUpdate()
  {
    if (this.locationOfOnDuplicateKeyUpdate == -2) {
      this.locationOfOnDuplicateKeyUpdate = getOnDuplicateKeyLocation(this.originalSql);
    }

    return this.locationOfOnDuplicateKeyUpdate;
  }

  protected synchronized boolean isOnDuplicateKeyUpdate() {
    return (getLocationOfOnDuplicateKeyUpdate() != -1);
  }

  protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
  {
    long sizeOfEntireBatch = 10L;
    long maxSizeOfParameterSet = 0L;

    for (int i = 0; i < numBatchedArgs; ++i) {
      BindValue[] paramArg = ((BatchedBindValues)this.batchedArgs.get(i)).batchedParameterValues;

      long sizeOfParameterSet = 0L;

      sizeOfParameterSet += (this.parameterCount + 7) / 8;

      sizeOfParameterSet += this.parameterCount * 2;

      for (int j = 0; j < this.parameterBindings.length; ++j)
        if (!(paramArg[j].isNull))
        {
          long size = paramArg[j].getBoundLength();

          if (paramArg[j].isLongData)
            if (size != -1L)
              sizeOfParameterSet += size;

          else
            sizeOfParameterSet += size;

        }


      sizeOfEntireBatch += sizeOfParameterSet;

      if (sizeOfParameterSet > maxSizeOfParameterSet)
        maxSizeOfParameterSet = sizeOfParameterSet;

    }

    return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
  }

  protected int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet)
    throws SQLException
  {
    BindValue[] paramArg = ((BatchedBindValues)paramSet).batchedParameterValues;

    for (int j = 0; j < paramArg.length; ++j)
      if (paramArg[j].isNull) {
        batchedStatement.setNull(batchedParamIndex++, 0);
      } else {
        Object value;
        if (paramArg[j].isLongData) {
          value = paramArg[j].value;

          if (value instanceof InputStream) {
            batchedStatement.setBinaryStream(batchedParamIndex++, (InputStream)value, (int)paramArg[j].bindLength);
          }
          else
          {
            batchedStatement.setCharacterStream(batchedParamIndex++, (Reader)value, (int)paramArg[j].bindLength);
          }

        }
        else
        {
          switch (paramArg[j].bufferType)
          {
          case 1:
            batchedStatement.setByte(batchedParamIndex++, paramArg[j].byteBinding);

            break;
          case 2:
            batchedStatement.setShort(batchedParamIndex++, paramArg[j].shortBinding);

            break;
          case 3:
            batchedStatement.setInt(batchedParamIndex++, paramArg[j].intBinding);

            break;
          case 8:
            batchedStatement.setLong(batchedParamIndex++, paramArg[j].longBinding);

            break;
          case 4:
            batchedStatement.setFloat(batchedParamIndex++, paramArg[j].floatBinding);

            break;
          case 5:
            batchedStatement.setDouble(batchedParamIndex++, paramArg[j].doubleBinding);

            break;
          case 11:
            batchedStatement.setTime(batchedParamIndex++, (Time)paramArg[j].value);

            break;
          case 10:
            batchedStatement.setDate(batchedParamIndex++, (java.sql.Date)paramArg[j].value);

            break;
          case 7:
          case 12:
            batchedStatement.setTimestamp(batchedParamIndex++, (Timestamp)paramArg[j].value);

            break;
          case 0:
          case 15:
          case 246:
          case 253:
          case 254:
            value = paramArg[j].value;

            if (value instanceof byte[]) {
              batchedStatement.setBytes(batchedParamIndex, (byte[])value);
            }
            else {
              batchedStatement.setString(batchedParamIndex, (String)value);
            }

            if (batchedStatement instanceof ServerPreparedStatement) {
              BindValue asBound = ((ServerPreparedStatement)batchedStatement).getBinding(batchedParamIndex, false);

              asBound.bufferType = paramArg[j].bufferType;
            }

            ++batchedParamIndex;

            break;
          default:
            throw new IllegalArgumentException("Unknown type when re-binding parameter into batched statement for parameter index " + batchedParamIndex);
          }

        }

      }


    return batchedParamIndex;
  }

  protected boolean containsOnDuplicateKeyUpdateInSQL() {
    return this.hasOnDuplicateKeyUpdate; }

  protected PreparedStatement prepareBatchedInsertSQL(ConnectionImpl localConn, int numBatches) throws SQLException {
    PreparedStatement pstmt;
    try {
      pstmt = new ServerPreparedStatement(localConn, this.parseInfo.getSqlForBatch(numBatches), this.currentCatalog, this.resultSetConcurrency, this.resultSetType);
      pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);

      return pstmt;
    } catch (UnsupportedEncodingException e) {
      SQLException sqlEx = SQLError.createSQLException("Unable to prepare batch statement", "S1000", getExceptionInterceptor());
      sqlEx.initCause(e);

      throw sqlEx;
    }
  }

  static
  {
    if (Util.isJdbc4())
      try {
        JDBC_4_SPS_CTOR = Class.forName("com.mysql.jdbc.JDBC4ServerPreparedStatement").getConstructor(new Class[] { ConnectionImpl.class, String.class, String.class, Integer.TYPE, Integer.TYPE });
      }
      catch (SecurityException e)
      {
        throw new RuntimeException(e);
      } catch (NoSuchMethodException e) {
        throw new RuntimeException(e);
      } catch (ClassNotFoundException e) {
        throw new RuntimeException(e);
      }

    JDBC_4_SPS_CTOR = null;
  }

  public static class BindValue
  {
    long boundBeforeExecutionNum = 0L;
    public long bindLength;
    int bufferType;
    byte byteBinding;
    double doubleBinding;
    float floatBinding;
    int intBinding;
    public boolean isLongData;
    public boolean isNull;
    boolean isSet = false;
    long longBinding;
    short shortBinding;
    public Object value;

    BindValue()
    {
    }

    BindValue(BindValue copyMe)
    {
      this.value = copyMe.value;
      this.isSet = copyMe.isSet;
      this.isLongData = copyMe.isLongData;
      this.isNull = copyMe.isNull;
      this.bufferType = copyMe.bufferType;
      this.bindLength = copyMe.bindLength;
      this.byteBinding = copyMe.byteBinding;
      this.shortBinding = copyMe.shortBinding;
      this.intBinding = copyMe.intBinding;
      this.longBinding = copyMe.longBinding;
      this.floatBinding = copyMe.floatBinding;
      this.doubleBinding = copyMe.doubleBinding;
    }

    void reset() {
      this.isSet = false;
      this.value = null;
      this.isLongData = false;

      this.byteBinding = 0;
      this.shortBinding = 0;
      this.intBinding = 0;
      this.longBinding = 0L;
      this.floatBinding = 0.0F;
      this.doubleBinding = 0.0D;
    }

    public String toString() {
      return toString(false);
    }

    public String toString(boolean quoteIfNeeded) {
      if (this.isLongData) {
        return "' STREAM DATA '";
      }

      switch (this.bufferType)
      {
      case 1:
        return String.valueOf(this.byteBinding);
      case 2:
        return String.valueOf(this.shortBinding);
      case 3:
        return String.valueOf(this.intBinding);
      case 8:
        return String.valueOf(this.longBinding);
      case 4:
        return String.valueOf(this.floatBinding);
      case 5:
        return String.valueOf(this.doubleBinding);
      case 7:
      case 10:
      case 11:
      case 12:
      case 15:
      case 253:
      case 254:
        if (quoteIfNeeded)
          return "'" + String.valueOf(this.value) + "'";

        return String.valueOf(this.value);
      }

      if (this.value instanceof byte[]) {
        return "byte data";
      }

      if (quoteIfNeeded)
        return "'" + String.valueOf(this.value) + "'";

      return String.valueOf(this.value);
    }

    long getBoundLength()
    {
      if (this.isNull) {
        return 0L;
      }

      if (this.isLongData) {
        return this.bindLength;
      }

      switch (this.bufferType)
      {
      case 1:
        return 1L;
      case 2:
        return 2L;
      case 3:
        return 4L;
      case 8:
        return 8L;
      case 4:
        return 4L;
      case 5:
        return 8L;
      case 11:
        return 9L;
      case 10:
        return 7L;
      case 7:
      case 12:
        return 11L;
      case 0:
      case 15:
      case 246:
      case 253:
      case 254:
        if (this.value instanceof byte[])
          return ((byte[])this.value).length;

        return ((String)this.value).length();
      }

      return 0L;
    }
  }

  static class BatchedBindValues
  {
    ServerPreparedStatement.BindValue[] batchedParameterValues;

    BatchedBindValues(ServerPreparedStatement.BindValue[] paramVals)
    {
      int numParams = paramVals.length;

      this.batchedParameterValues = new ServerPreparedStatement.BindValue[numParams];

      for (int i = 0; i < numParams; ++i)
        this.batchedParameterValues[i] = new ServerPreparedStatement.BindValue(paramVals[i]);
    }
  }
}