package com.mysql.jdbc;

public abstract interface StreamingNotifiable
{
  public abstract void setWasStreamingResults();
}