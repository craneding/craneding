package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.Iterator;

public abstract class IterateBlock
{
  DatabaseMetaData.IteratorWithCleanup iteratorWithCleanup;
  Iterator javaIterator;
  boolean stopIterating = false;

  IterateBlock(DatabaseMetaData.IteratorWithCleanup i)
  {
    this.iteratorWithCleanup = i;
    this.javaIterator = null;
  }

  IterateBlock(Iterator i) {
    this.javaIterator = i;
    this.iteratorWithCleanup = null;
  }

  public void doForAll() throws SQLException {
    if (this.iteratorWithCleanup != null) try {
        do {
          if (!(this.iteratorWithCleanup.hasNext())) break label38;
          forEach(this.iteratorWithCleanup.next());
        }
        while (!(this.stopIterating));
        label38: break label38:
      }
      finally
      {
        this.iteratorWithCleanup.close();
      }
    do {
      if (!(this.javaIterator.hasNext())) return;
      forEach(this.javaIterator.next());
    }
    while (!(this.stopIterating));
  }

  abstract void forEach(Object paramObject)
    throws SQLException;

  public final boolean fullIteration()
  {
    return (!(this.stopIterating));
  }
}