package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public abstract interface BalanceStrategy extends Extension
{
  public abstract Connection pickConnection(LoadBalancingConnectionProxy paramLoadBalancingConnectionProxy, List paramList, Map paramMap, long[] paramArrayOfLong, int paramInt)
    throws SQLException;
}