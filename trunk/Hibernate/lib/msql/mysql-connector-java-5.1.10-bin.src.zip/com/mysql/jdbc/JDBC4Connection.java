package com.mysql.jdbc;

import java.sql.Array;
import java.sql.NClob;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Struct;
import java.util.Properties;

public class JDBC4Connection extends ConnectionImpl
{
  private JDBC4ClientInfoProvider infoProvider;

  public JDBC4Connection(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
    throws SQLException
  {
    super(hostToConnectTo, portToConnectTo, info, databaseToConnectTo, url);
  }

  public SQLXML createSQLXML() throws SQLException
  {
    return new JDBC4MysqlSQLXML(getExceptionInterceptor());
  }

  public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
    throw SQLError.notImplemented();
  }

  public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
    throw SQLError.notImplemented();
  }

  public Properties getClientInfo() throws SQLException {
    return getClientInfoProviderImpl().getClientInfo(this);
  }

  public String getClientInfo(String name) throws SQLException {
    return getClientInfoProviderImpl().getClientInfo(this, name); } 
  // ERROR //
  public synchronized boolean isValid(int timeout) throws SQLException { // Byte code:
    //   0: aload_0
    //   1: invokevirtual 9	com/mysql/jdbc/JDBC4Connection:isClosed	()Z
    //   4: ifeq +5 -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: invokevirtual 10	com/mysql/jdbc/JDBC4Connection:getMutex	()Ljava/lang/Object;
    //   13: dup
    //   14: astore_2
    //   15: monitorenter
    //   16: aload_0
    //   17: iconst_0
    //   18: iload_1
    //   19: sipush 1000
    //   22: imul
    //   23: invokevirtual 11	com/mysql/jdbc/JDBC4Connection:pingInternal	(ZI)V
    //   26: goto +17 -> 43
    //   29: astore_3
    //   30: aload_0
    //   31: invokevirtual 13	com/mysql/jdbc/JDBC4Connection:abortInternal	()V
    //   34: goto +5 -> 39
    //   37: astore 4
    //   39: iconst_0
    //   40: aload_2
    //   41: monitorexit
    //   42: ireturn
    //   43: aload_2
    //   44: monitorexit
    //   45: goto +10 -> 55
    //   48: astore 5
    //   50: aload_2
    //   51: monitorexit
    //   52: aload 5
    //   54: athrow
    //   55: goto +6 -> 61
    //   58: astore_2
    //   59: iconst_0
    //   60: ireturn
    //   61: iconst_1
    //   62: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   16	26	29	java/lang/Throwable
    //   30	34	37	java/lang/Throwable
    //   16	42	48	finally
    //   43	45	48	finally
    //   48	52	48	finally
    //   9	42	58	java/lang/Throwable
    //   43	55	58	java/lang/Throwable } 
  public void setClientInfo(Properties properties) throws SQLClientInfoException { try { getClientInfoProviderImpl().setClientInfo(this, properties);
    } catch (SQLClientInfoException ciEx) {
      throw ciEx;
    } catch (SQLException sqlEx) {
      SQLClientInfoException clientInfoEx = new SQLClientInfoException();
      clientInfoEx.initCause(sqlEx);

      throw clientInfoEx;
    }
  }

  public void setClientInfo(String name, String value) throws SQLClientInfoException {
    try {
      getClientInfoProviderImpl().setClientInfo(this, name, value);
    } catch (SQLClientInfoException ciEx) {
      throw ciEx;
    } catch (SQLException sqlEx) {
      SQLClientInfoException clientInfoEx = new SQLClientInfoException();
      clientInfoEx.initCause(sqlEx);

      throw clientInfoEx;
    }
  }

  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    checkClosed();

    return iface.isInstance(this);
  }

  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      return iface.cast(this);
    } catch (ClassCastException cce) {
      throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
    }
  }

  public java.sql.Blob createBlob()
  {
    return new Blob(getExceptionInterceptor());
  }

  public java.sql.Clob createClob()
  {
    return new Clob(getExceptionInterceptor());
  }

  public NClob createNClob()
  {
    return new JDBC4NClob(getExceptionInterceptor());
  }

  protected synchronized JDBC4ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
    if (this.infoProvider == null) {
      try {
        try {
          this.infoProvider = ((JDBC4ClientInfoProvider)Util.getInstance(getClientInfoProvider(), new Class[0], new Object[0], getExceptionInterceptor()));
        }
        catch (SQLException sqlEx) {
          if (sqlEx.getCause() instanceof ClassCastException)
          {
            this.infoProvider = ((JDBC4ClientInfoProvider)Util.getInstance("com.mysql.jdbc." + getClientInfoProvider(), new Class[0], new Object[0], getExceptionInterceptor()));
          }
        }
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("JDBC4Connection.ClientInfoNotImplemented", new Object[] { getClientInfoProvider() }), "S1009", getExceptionInterceptor());
      }

      this.infoProvider.initialize(this, this.props);
    }

    return this.infoProvider;
  }
}