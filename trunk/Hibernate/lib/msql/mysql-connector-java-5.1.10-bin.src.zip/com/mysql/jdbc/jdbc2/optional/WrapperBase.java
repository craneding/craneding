package com.mysql.jdbc.jdbc2.optional;

import com.mysql.jdbc.ExceptionInterceptor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.SQLException;
import java.util.Map;

abstract class WrapperBase
{
  protected MysqlPooledConnection pooledConnection;
  protected Map unwrappedInterfaces = null;
  protected ExceptionInterceptor exceptionInterceptor;

  protected void checkAndFireConnectionError(SQLException sqlEx)
    throws SQLException
  {
    if ((this.pooledConnection != null) && 
      ("08S01".equals(sqlEx.getSQLState())))
    {
      this.pooledConnection.callConnectionEventListeners(1, sqlEx);
    }

    throw sqlEx;
  }

  protected WrapperBase(MysqlPooledConnection pooledConnection)
  {
    this.pooledConnection = pooledConnection;
    this.exceptionInterceptor = this.pooledConnection.getExceptionInterceptor(); }

  protected class ConnectionErrorFiringInvocationHandler implements InvocationHandler {
    Object invokeOn;
    private final WrapperBase this$0;

    public ConnectionErrorFiringInvocationHandler(, Object toInvokeOn) { this.this$0 = this$0;

      this.invokeOn = null;

      this.invokeOn = toInvokeOn;
    }

    public Object invoke(, Method method, Object[] args) throws Throwable
    {
      Object result = null;
      try
      {
        result = method.invoke(this.invokeOn, args);

        if (result != null)
          result = proxyIfInterfaceIsJdbc(result, result.getClass());
      }
      catch (InvocationTargetException e)
      {
        if (e.getTargetException() instanceof SQLException) {
          this.this$0.checkAndFireConnectionError((SQLException)e.getTargetException());
        }
        else
          throw e;

      }

      return result;
    }

    private Object proxyIfInterfaceIsJdbc(, Class clazz)
    {
      Class[] interfaces = clazz.getInterfaces();

      int i = 0; if (i < interfaces.length) {
        String packageName = interfaces[i].getPackage().getName();

        if (("java.sql".equals(packageName)) || ("javax.sql".equals(packageName)))
        {
          return Proxy.newProxyInstance(toProxy.getClass().getClassLoader(), interfaces, new ConnectionErrorFiringInvocationHandler(this.this$0, toProxy));
        }

        return proxyIfInterfaceIsJdbc(toProxy, interfaces[i]);
      }

      return toProxy;
    }
  }
}