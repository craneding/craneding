package com.mysql.jdbc;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BlobFromLocator
  implements Blob
{
  private List primaryKeyColumns = null;
  private List primaryKeyValues = null;
  private ResultSetImpl creatorResultSet;
  private String blobColumnName = null;
  private String tableName = null;
  private int numColsInResultSet = 0;
  private int numPrimaryKeys = 0;
  private String quotedId;
  private ExceptionInterceptor exceptionInterceptor;

  BlobFromLocator(ResultSetImpl creatorResultSetToSet, int blobColumnIndex, ExceptionInterceptor exceptionInterceptor)
    throws SQLException
  {
    this.exceptionInterceptor = exceptionInterceptor;
    this.creatorResultSet = creatorResultSetToSet;

    this.numColsInResultSet = this.creatorResultSet.fields.length;
    this.quotedId = this.creatorResultSet.connection.getMetaData().getIdentifierQuoteString();

    if (this.numColsInResultSet > 1) {
      this.primaryKeyColumns = new ArrayList();
      this.primaryKeyValues = new ArrayList();

      for (i = 0; i < this.numColsInResultSet; ++i)
        if (this.creatorResultSet.fields[i].isPrimaryKey()) {
          StringBuffer keyName = new StringBuffer();
          keyName.append(this.quotedId);

          String originalColumnName = this.creatorResultSet.fields[i].getOriginalName();

          if ((originalColumnName != null) && (originalColumnName.length() > 0))
          {
            keyName.append(originalColumnName);
          }
          else { keyName.append(this.creatorResultSet.fields[i].getName());
          }

          keyName.append(this.quotedId);

          this.primaryKeyColumns.add(keyName.toString());
          this.primaryKeyValues.add(this.creatorResultSet.getString(i + 1));
        }
    }
    else
    {
      notEnoughInformationInQuery();
    }

    this.numPrimaryKeys = this.primaryKeyColumns.size();

    if (this.numPrimaryKeys == 0) {
      notEnoughInformationInQuery();
    }

    if (this.creatorResultSet.fields[0].getOriginalTableName() != null) {
      tableNameBuffer = new StringBuffer();

      String databaseName = this.creatorResultSet.fields[0].getDatabaseName();

      if ((databaseName != null) && (databaseName.length() > 0)) {
        tableNameBuffer.append(this.quotedId);
        tableNameBuffer.append(databaseName);
        tableNameBuffer.append(this.quotedId);
        tableNameBuffer.append('.');
      }

      tableNameBuffer.append(this.quotedId);
      tableNameBuffer.append(this.creatorResultSet.fields[0].getOriginalTableName());

      tableNameBuffer.append(this.quotedId);

      this.tableName = tableNameBuffer.toString();
    } else {
      tableNameBuffer = new StringBuffer();

      tableNameBuffer.append(this.quotedId);
      tableNameBuffer.append(this.creatorResultSet.fields[0].getTableName());

      tableNameBuffer.append(this.quotedId);

      this.tableName = tableNameBuffer.toString();
    }

    this.blobColumnName = this.quotedId + this.creatorResultSet.getString(blobColumnIndex) + this.quotedId;
  }

  private void notEnoughInformationInQuery() throws SQLException
  {
    throw SQLError.createSQLException("Emulated BLOB locators must come from a ResultSet with only one table selected, and all primary keys selected", "S1000", this.exceptionInterceptor);
  }

  public OutputStream setBinaryStream(long indexToWriteAt)
    throws SQLException
  {
    throw SQLError.notImplemented();
  }

  public InputStream getBinaryStream()
    throws SQLException
  {
    return new BufferedInputStream(new LocatorInputStream(this), this.creatorResultSet.connection.getLocatorFetchBufferSize());
  }

  public int setBytes(long writeAt, byte[] bytes, int offset, int length)
    throws SQLException
  {
    PreparedStatement pStmt = null;

    if (offset + length > bytes.length) {
      length = bytes.length - offset;
    }

    byte[] bytesToWrite = new byte[length];
    System.arraycopy(bytes, offset, bytesToWrite, 0, length);

    StringBuffer query = new StringBuffer("UPDATE ");
    query.append(this.tableName);
    query.append(" SET ");
    query.append(this.blobColumnName);
    query.append(" = INSERT(");
    query.append(this.blobColumnName);
    query.append(", ");
    query.append(writeAt);
    query.append(", ");
    query.append(length);
    query.append(", ?) WHERE ");

    query.append((String)this.primaryKeyColumns.get(0));
    query.append(" = ?");

    for (int i = 1; i < this.numPrimaryKeys; ++i) {
      query.append(" AND ");
      query.append((String)this.primaryKeyColumns.get(i));
      query.append(" = ?");
    }

    try
    {
      pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());

      pStmt.setBytes(1, bytesToWrite);

      for (i = 0; i < this.numPrimaryKeys; ++i) {
        pStmt.setString(i + 2, (String)this.primaryKeyValues.get(i));
      }

      int rowsUpdated = pStmt.executeUpdate();

      if (rowsUpdated != 1)
        throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000", this.exceptionInterceptor);

    }
    finally
    {
      if (pStmt != null) {
        try {
          pStmt.close();
        }
        catch (SQLException sqlEx)
        {
        }
        pStmt = null;
      }
    }

    return (int)length();
  }

  public int setBytes(long writeAt, byte[] bytes)
    throws SQLException
  {
    return setBytes(writeAt, bytes, 0, bytes.length);
  }

  public byte[] getBytes(long pos, int length)
    throws SQLException
  {
    PreparedStatement pStmt = null;
    try
    {
      byte[] arrayOfByte;
      pStmt = createGetBytesStatement();

      return getBytesInternal(pStmt, pos, length);
    } finally {
      if (pStmt != null) {
        try {
          pStmt.close();
        }
        catch (SQLException sqlEx)
        {
        }
        pStmt = null; }  }  } 
  // ERROR //
  public long length() throws SQLException { // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: new 18	java/lang/StringBuffer
    //   7: dup
    //   8: ldc 66
    //   10: invokespecial 44	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   13: astore_3
    //   14: aload_3
    //   15: aload_0
    //   16: getfield 5	com/mysql/jdbc/BlobFromLocator:blobColumnName	Ljava/lang/String;
    //   19: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   22: pop
    //   23: aload_3
    //   24: ldc 67
    //   26: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   29: pop
    //   30: aload_3
    //   31: aload_0
    //   32: getfield 6	com/mysql/jdbc/BlobFromLocator:tableName	Ljava/lang/String;
    //   35: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   38: pop
    //   39: aload_3
    //   40: ldc 68
    //   42: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   45: pop
    //   46: aload_3
    //   47: aload_0
    //   48: getfield 3	com/mysql/jdbc/BlobFromLocator:primaryKeyColumns	Ljava/util/List;
    //   51: iconst_0
    //   52: invokeinterface 51 2 0
    //   57: checkcast 52	java/lang/String
    //   60: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   63: pop
    //   64: aload_3
    //   65: ldc 53
    //   67: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   70: pop
    //   71: iconst_1
    //   72: istore 4
    //   74: iload 4
    //   76: aload_0
    //   77: getfield 8	com/mysql/jdbc/BlobFromLocator:numPrimaryKeys	I
    //   80: if_icmpge +42 -> 122
    //   83: aload_3
    //   84: ldc 54
    //   86: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   89: pop
    //   90: aload_3
    //   91: aload_0
    //   92: getfield 3	com/mysql/jdbc/BlobFromLocator:primaryKeyColumns	Ljava/util/List;
    //   95: iload 4
    //   97: invokeinterface 51 2 0
    //   102: checkcast 52	java/lang/String
    //   105: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   108: pop
    //   109: aload_3
    //   110: ldc 53
    //   112: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   115: pop
    //   116: iinc 4 1
    //   119: goto -45 -> 74
    //   122: aload_0
    //   123: getfield 9	com/mysql/jdbc/BlobFromLocator:creatorResultSet	Lcom/mysql/jdbc/ResultSetImpl;
    //   126: getfield 11	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   129: aload_3
    //   130: invokevirtual 24	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   133: invokevirtual 55	com/mysql/jdbc/ConnectionImpl:prepareStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
    //   136: astore_2
    //   137: iconst_0
    //   138: istore 4
    //   140: iload 4
    //   142: aload_0
    //   143: getfield 8	com/mysql/jdbc/BlobFromLocator:numPrimaryKeys	I
    //   146: if_icmpge +33 -> 179
    //   149: aload_2
    //   150: iload 4
    //   152: iconst_1
    //   153: iadd
    //   154: aload_0
    //   155: getfield 4	com/mysql/jdbc/BlobFromLocator:primaryKeyValues	Ljava/util/List;
    //   158: iload 4
    //   160: invokeinterface 51 2 0
    //   165: checkcast 52	java/lang/String
    //   168: invokeinterface 57 3 0
    //   173: iinc 4 1
    //   176: goto -36 -> 140
    //   179: aload_2
    //   180: invokeinterface 69 1 0
    //   185: astore_1
    //   186: aload_1
    //   187: invokeinterface 70 1 0
    //   192: ifeq +18 -> 210
    //   195: aload_1
    //   196: iconst_1
    //   197: invokeinterface 71 2 0
    //   202: lstore 4
    //   204: jsr +26 -> 230
    //   207: lload 4
    //   209: lreturn
    //   210: ldc 59
    //   212: ldc 34
    //   214: aload_0
    //   215: getfield 1	com/mysql/jdbc/BlobFromLocator:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
    //   218: invokestatic 35	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   221: athrow
    //   222: astore 6
    //   224: jsr +6 -> 230
    //   227: aload 6
    //   229: athrow
    //   230: astore 7
    //   232: aload_1
    //   233: ifnull +16 -> 249
    //   236: aload_1
    //   237: invokeinterface 72 1 0
    //   242: goto +5 -> 247
    //   245: astore 8
    //   247: aconst_null
    //   248: astore_1
    //   249: aload_2
    //   250: ifnull +16 -> 266
    //   253: aload_2
    //   254: invokeinterface 60 1 0
    //   259: goto +5 -> 264
    //   262: astore 8
    //   264: aconst_null
    //   265: astore_2
    //   266: ret 7
    //
    // Exception table:
    //   from	to	target	type
    //   122	207	222	finally
    //   210	227	222	finally
    //   236	242	245	SQLException
    //   253	259	262	SQLException } 
  public long position(Blob pattern, long start) throws SQLException { return position(pattern.getBytes(0L, (int)pattern.length()), start); } 
  // ERROR //
  public long position(byte[] pattern, long start) throws SQLException { // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aconst_null
    //   4: astore 5
    //   6: new 18	java/lang/StringBuffer
    //   9: dup
    //   10: ldc 76
    //   12: invokespecial 44	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   15: astore 6
    //   17: aload 6
    //   19: ldc 77
    //   21: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   24: pop
    //   25: aload 6
    //   27: aload_0
    //   28: getfield 5	com/mysql/jdbc/BlobFromLocator:blobColumnName	Ljava/lang/String;
    //   31: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   34: pop
    //   35: aload 6
    //   37: ldc 47
    //   39: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   42: pop
    //   43: aload 6
    //   45: lload_2
    //   46: invokevirtual 48	java/lang/StringBuffer:append	(J)Ljava/lang/StringBuffer;
    //   49: pop
    //   50: aload 6
    //   52: ldc 67
    //   54: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   57: pop
    //   58: aload 6
    //   60: aload_0
    //   61: getfield 6	com/mysql/jdbc/BlobFromLocator:tableName	Ljava/lang/String;
    //   64: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   67: pop
    //   68: aload 6
    //   70: ldc 68
    //   72: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   75: pop
    //   76: aload 6
    //   78: aload_0
    //   79: getfield 3	com/mysql/jdbc/BlobFromLocator:primaryKeyColumns	Ljava/util/List;
    //   82: iconst_0
    //   83: invokeinterface 51 2 0
    //   88: checkcast 52	java/lang/String
    //   91: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   94: pop
    //   95: aload 6
    //   97: ldc 53
    //   99: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   102: pop
    //   103: iconst_1
    //   104: istore 7
    //   106: iload 7
    //   108: aload_0
    //   109: getfield 8	com/mysql/jdbc/BlobFromLocator:numPrimaryKeys	I
    //   112: if_icmpge +45 -> 157
    //   115: aload 6
    //   117: ldc 54
    //   119: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   122: pop
    //   123: aload 6
    //   125: aload_0
    //   126: getfield 3	com/mysql/jdbc/BlobFromLocator:primaryKeyColumns	Ljava/util/List;
    //   129: iload 7
    //   131: invokeinterface 51 2 0
    //   136: checkcast 52	java/lang/String
    //   139: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   142: pop
    //   143: aload 6
    //   145: ldc 53
    //   147: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   150: pop
    //   151: iinc 7 1
    //   154: goto -48 -> 106
    //   157: aload_0
    //   158: getfield 9	com/mysql/jdbc/BlobFromLocator:creatorResultSet	Lcom/mysql/jdbc/ResultSetImpl;
    //   161: getfield 11	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/ConnectionImpl;
    //   164: aload 6
    //   166: invokevirtual 24	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   169: invokevirtual 55	com/mysql/jdbc/ConnectionImpl:prepareStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
    //   172: astore 5
    //   174: aload 5
    //   176: iconst_1
    //   177: aload_1
    //   178: invokeinterface 56 3 0
    //   183: iconst_0
    //   184: istore 7
    //   186: iload 7
    //   188: aload_0
    //   189: getfield 8	com/mysql/jdbc/BlobFromLocator:numPrimaryKeys	I
    //   192: if_icmpge +34 -> 226
    //   195: aload 5
    //   197: iload 7
    //   199: iconst_2
    //   200: iadd
    //   201: aload_0
    //   202: getfield 4	com/mysql/jdbc/BlobFromLocator:primaryKeyValues	Ljava/util/List;
    //   205: iload 7
    //   207: invokeinterface 51 2 0
    //   212: checkcast 52	java/lang/String
    //   215: invokeinterface 57 3 0
    //   220: iinc 7 1
    //   223: goto -37 -> 186
    //   226: aload 5
    //   228: invokeinterface 69 1 0
    //   233: astore 4
    //   235: aload 4
    //   237: invokeinterface 70 1 0
    //   242: ifeq +19 -> 261
    //   245: aload 4
    //   247: iconst_1
    //   248: invokeinterface 71 2 0
    //   253: lstore 7
    //   255: jsr +26 -> 281
    //   258: lload 7
    //   260: lreturn
    //   261: ldc 59
    //   263: ldc 34
    //   265: aload_0
    //   266: getfield 1	com/mysql/jdbc/BlobFromLocator:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
    //   269: invokestatic 35	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   272: athrow
    //   273: astore 9
    //   275: jsr +6 -> 281
    //   278: aload 9
    //   280: athrow
    //   281: astore 10
    //   283: aload 4
    //   285: ifnull +18 -> 303
    //   288: aload 4
    //   290: invokeinterface 72 1 0
    //   295: goto +5 -> 300
    //   298: astore 11
    //   300: aconst_null
    //   301: astore 4
    //   303: aload 5
    //   305: ifnull +18 -> 323
    //   308: aload 5
    //   310: invokeinterface 60 1 0
    //   315: goto +5 -> 320
    //   318: astore 11
    //   320: aconst_null
    //   321: astore 5
    //   323: ret 10
    //
    // Exception table:
    //   from	to	target	type
    //   157	258	273	finally
    //   261	278	273	finally
    //   288	295	298	SQLException
    //   308	315	318	SQLException } 
  public void truncate(long length) throws SQLException { PreparedStatement pStmt = null;

    StringBuffer query = new StringBuffer("UPDATE ");
    query.append(this.tableName);
    query.append(" SET ");
    query.append(this.blobColumnName);
    query.append(" = LEFT(");
    query.append(this.blobColumnName);
    query.append(", ");
    query.append(length);
    query.append(") WHERE ");

    query.append((String)this.primaryKeyColumns.get(0));
    query.append(" = ?");

    for (int i = 1; i < this.numPrimaryKeys; ++i) {
      query.append(" AND ");
      query.append((String)this.primaryKeyColumns.get(i));
      query.append(" = ?");
    }

    try
    {
      pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());

      for (i = 0; i < this.numPrimaryKeys; ++i) {
        pStmt.setString(i + 1, (String)this.primaryKeyValues.get(i));
      }

      int rowsUpdated = pStmt.executeUpdate();

      if (rowsUpdated != 1)
        throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000", this.exceptionInterceptor);

    }
    finally
    {
      if (pStmt != null) {
        try {
          pStmt.close();
        }
        catch (SQLException sqlEx)
        {
        }
        pStmt = null;
      }
    }
  }

  PreparedStatement createGetBytesStatement() throws SQLException {
    StringBuffer query = new StringBuffer("SELECT SUBSTRING(");

    query.append(this.blobColumnName);
    query.append(", ");
    query.append("?");
    query.append(", ");
    query.append("?");
    query.append(") FROM ");
    query.append(this.tableName);
    query.append(" WHERE ");

    query.append((String)this.primaryKeyColumns.get(0));
    query.append(" = ?");

    for (int i = 1; i < this.numPrimaryKeys; ++i) {
      query.append(" AND ");
      query.append((String)this.primaryKeyColumns.get(i));
      query.append(" = ?");
    }

    return this.creatorResultSet.connection.prepareStatement(query.toString());
  }

  // ERROR //
  byte[] getBytesInternal(PreparedStatement pStmt, long pos, int length)
    throws SQLException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 5
    //   3: aload_1
    //   4: iconst_1
    //   5: lload_2
    //   6: invokeinterface 82 4 0
    //   11: aload_1
    //   12: iconst_2
    //   13: iload 4
    //   15: invokeinterface 83 3 0
    //   20: iconst_0
    //   21: istore 6
    //   23: iload 6
    //   25: aload_0
    //   26: getfield 8	com/mysql/jdbc/BlobFromLocator:numPrimaryKeys	I
    //   29: if_icmpge +33 -> 62
    //   32: aload_1
    //   33: iload 6
    //   35: iconst_3
    //   36: iadd
    //   37: aload_0
    //   38: getfield 4	com/mysql/jdbc/BlobFromLocator:primaryKeyValues	Ljava/util/List;
    //   41: iload 6
    //   43: invokeinterface 51 2 0
    //   48: checkcast 52	java/lang/String
    //   51: invokeinterface 57 3 0
    //   56: iinc 6 1
    //   59: goto -36 -> 23
    //   62: aload_1
    //   63: invokeinterface 69 1 0
    //   68: astore 5
    //   70: aload 5
    //   72: invokeinterface 70 1 0
    //   77: ifeq +21 -> 98
    //   80: aload 5
    //   82: checkcast 84	com/mysql/jdbc/ResultSetImpl
    //   85: iconst_1
    //   86: iconst_1
    //   87: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:getBytes	(IZ)[B
    //   90: astore 6
    //   92: jsr +26 -> 118
    //   95: aload 6
    //   97: areturn
    //   98: ldc 59
    //   100: ldc 34
    //   102: aload_0
    //   103: getfield 1	com/mysql/jdbc/BlobFromLocator:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
    //   106: invokestatic 35	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   109: athrow
    //   110: astore 7
    //   112: jsr +6 -> 118
    //   115: aload 7
    //   117: athrow
    //   118: astore 8
    //   120: aload 5
    //   122: ifnull +18 -> 140
    //   125: aload 5
    //   127: invokeinterface 72 1 0
    //   132: goto +5 -> 137
    //   135: astore 9
    //   137: aconst_null
    //   138: astore 5
    //   140: ret 8
    //
    // Exception table:
    //   from	to	target	type
    //   3	95	110	finally
    //   98	115	110	finally
    //   125	132	135	SQLException
  }

  public void free()
    throws SQLException
  {
    this.creatorResultSet = null;
    this.primaryKeyColumns = null;
    this.primaryKeyValues = null;
  }

  public InputStream getBinaryStream(long pos, long length) throws SQLException {
    return new LocatorInputStream(this, pos, length);
  }

  static ExceptionInterceptor access$000(BlobFromLocator x0)
  {
    return x0.exceptionInterceptor;
  }

  class LocatorInputStream extends InputStream
  {
    long currentPositionInBlob;
    long length;
    PreparedStatement pStmt;
    private final BlobFromLocator this$0;

    LocatorInputStream()
      throws SQLException
    {
      this.this$0 = this$0;

      this.currentPositionInBlob = 0L;

      this.length = 0L;

      this.pStmt = null;

      this.length = this$0.length();
      this.pStmt = this$0.createGetBytesStatement(); }

    LocatorInputStream(, long pos, long len) throws SQLException {
      this.this$0 = this$0;

      this.currentPositionInBlob = 0L;

      this.length = 0L;

      this.pStmt = null;

      this.length = (pos + len);
      this.currentPositionInBlob = pos;
      long blobLength = this$0.length();

      if (pos + len > blobLength) {
        throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamLength", new Object[] { new Long(blobLength), new Long(pos), new Long(len) }), "S1009", BlobFromLocator.access$000(this$0));
      }

      if (pos < 1L) {
        throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamPos"), "S1009", BlobFromLocator.access$000(this$0));
      }

      if (pos > blobLength)
        throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamPos"), "S1009", BlobFromLocator.access$000(this$0));
    }

    public int read()
      throws IOException
    {
      if (this.currentPositionInBlob + 1L > this.length)
        return -1;

      try
      {
        byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob++ + 1L, 1);

        if (asBytes == null) {
          return -1;
        }

        return asBytes[0];
      } catch (SQLException sqlEx) {
        throw new IOException(sqlEx.toString());
      }
    }

    public int read(, int off, int len)
      throws IOException
    {
      if (this.currentPositionInBlob + 1L > this.length)
        return -1;

      try
      {
        byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, len);

        if (asBytes == null) {
          return -1;
        }

        System.arraycopy(asBytes, 0, b, off, asBytes.length);

        this.currentPositionInBlob += asBytes.length;

        return asBytes.length;
      } catch (SQLException sqlEx) {
        throw new IOException(sqlEx.toString());
      }
    }

    public int read()
      throws IOException
    {
      if (this.currentPositionInBlob + 1L > this.length)
        return -1;

      try
      {
        byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, b.length);

        if (asBytes == null) {
          return -1;
        }

        System.arraycopy(asBytes, 0, b, 0, asBytes.length);

        this.currentPositionInBlob += asBytes.length;

        return asBytes.length;
      } catch (SQLException sqlEx) {
        throw new IOException(sqlEx.toString());
      }
    }

    public void close()
      throws IOException
    {
      if (this.pStmt != null)
        try {
          this.pStmt.close();
        } catch (SQLException sqlEx) {
          throw new IOException(sqlEx.toString());
        }


      super.close();
    }
  }
}